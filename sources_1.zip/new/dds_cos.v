`timescale 1ns / 1ps
module dds_cos#
	(
		parameter     	F_WORD = 32'd429496729	,//4294967296(2^32)*i(频率)/10000000
        	parameter    	P_WORD = 13'd2048	
	)
	(
    		input     	wire    		clk			,
    		input     	wire    		rest_n			,	
    		//input     wire    [9:0]data_in,
    		output 		wire    	[11:0]	rom_data_cos		
    		
    	);
    	
    	reg 		[31:0]	fre_add        			;	
        reg 		[12:0]	rom_addr_reg    		;
	
 	always@(posedge clk or negedge rest_n)
         if(!rest_n) 
             fre_add <= 0;
         else
             fre_add    <= fre_add + F_WORD;
        always@(posedge clk or negedge rest_n)
         if(!rest_n) 
             rom_addr_reg <= 0;
         else
             rom_addr_reg <= fre_add[31:19] + P_WORD;
 	
 	/*
 	cos
 	*/	 
       sin_rom cos
       (
		.clka(clk)		,    	// input wire clka
  		.addra(rom_addr_reg)	,  	// input wire [12 : 0] addra
  		.douta(rom_data_cos)  	// output wire [11 : 0] douta
	);

endmodule 
