`timescale 1ns / 1ps
module ADC_fft
	(
		input 	wire			clk		,
		input 	wire			rest		,
		input	wire		[12:0]	adc_in		,
		
		/**** rest_n - clk_PLL ****/
		output 	wire		rest_n			,
		output 	wire		fft_clk			,
			
		output 	wire 			adc_clk		,
		output 	wire		[30:0]	IM_FFT_data	,
		output 	wire		[30:0]	RE_FFT_data	,
		output 	wire		[13:0]	POINT_FFT	,
		output 	wire			FFT_data_begin		
		
    	);
    	
    	/***** rest_n *****/
    	wire		locked			;
    	assign rest_n = rest & locked		;
    	
    	/***** ad9226 *****/
    	wire 	[12:0] 	data_wave_adc 		;
    	
    	/***** fft *****/
    	wire	s_axis_config_tvalid		;
	/*
	主机准备好信号
	通知IP核可从tdata读取配置数据
	*/
	
	
	wire	s_axis_config_tready		;
	/*
	FFT_IP准备好信号
	已准备好接收配置数据，高有效
	*/
	
	
	
	
	/****** s_axis_data *****/
	reg	[31:0]	s_axis_data_tdata	;
	/*
	数据通道，并行输入
	[31:16][15:0]={IM,RE} 真实数据位
	*/
	 reg		s_axis_data_tvalid	;
	/*
	通知IP核此时所有输入数据有效，每个上升沿读一次
	由上游主服务器(其他模块给出 eg: adc)所发出的信号表明其能够提供数据
	必须拉高 点数个周期才能拉低 建议数据采集就一直拉高
	*/
	 wire		s_axis_data_tready	;
	/*
	由核心(FFT IP)使用以表示其已准备好接收数据
	IP核已准备好接收配置数据，高有效
	*/
	reg		s_axis_data_tlast	;
	/*
	最后一个输入数据时，手动拉高（该数据被读取后，数据将不被读取）
	*/
	
	
	
	/****** m_axis_data *****/
	 wire	[63:0]	m_axis_data_tdata	;
	/*
	当前配置下位二进制双补码（Two's Complement）输出 
	[62:32][30:0] = {IM，RE}
	*/
	 wire	[15:0]	m_axis_data_tuser	;
	/*
	[13:0]有效
	*/
	 wire		m_axis_data_tvalid	;
	/*
	通知外部设备此时所有输出数据有效，每个上升沿出一个数据
	*/

	
	 wire		m_axis_data_tready	;
	/*
	外设已准备好接收配置数据，高有效
	*/
	 wire		m_axis_data_tlast	;
	/*
	最后一个输出数据时，自动拉高
	*/	
	
	
	/***** event_frame_started *****/
	 wire		event_frame_started	;
	/*
	转换开始信号
	*/	
    	
    	/***** 内部信号 *****/
    	reg  	[13:0] 	data_cnt		;      // 数据计数（16384点）
    	reg         	frame_started		;      // 帧开始标志
    	
    	wire		adc_clk_main		;
    	
    	/***** 幅度谱计算时进行的补码处理 *****/
    	wire	[30:0]	IM_FFT_data_temp	;
	wire 	[30:0]	RE_FFT_data_temp	;
	
	/***** Hanning_Windows *****/
	wire	[15:0]	data_out_Hanning	;
	wire 	[15:0] 	data_wave 		;
	wire	[27:0]	Hanning_adc_out		;
	
	/***** ifft *****/
	wire			i_s_axis_config_tvalid	;
	/**** IP准备接受 ****/
    	wire			i_s_axis_config_tready	;
	/**** 数据信号 ****/
    	reg	signed	[31:0]	i_s_axis_data_tdata	;
    	/**** 输入数据有效 ****/
    	reg			i_s_axis_data_tvalid	;
    	/**** 可以接受数据 ****/
    	wire			i_s_axis_data_tready	;
    	/****** m_axis_data *****/
	 wire	signed	[62:0]	i_m_axis_data_tdata	;
	/*
	[62:32][30:0] = {IM，RE}
	*/
	/**** 输入最后一个数据 ****/
    	reg 			i_s_axis_data_tlast	;
	
	reg		[13:0]	i_data_cnt		;
	
	/**** 波形数据 ****/
	wire	signed	[30:0]	ifft_re_data		;
	
	assign ifft_re_data = i_m_axis_data_tdata[30:0]	;
	
	assign data_wave = Hanning_adc_out[27:12];
	
	
	/**** 最高位为1 表示为负数 最高位为0 表示为正数 ****/
	assign IM_FFT_data = (IM_FFT_data_temp[30] == 1'b1) ? ~IM_FFT_data_temp[30:0]:IM_FFT_data_temp[30:0]	;
    	assign RE_FFT_data = (RE_FFT_data_temp[30] == 1'b1) ? ~RE_FFT_data_temp[30:0]:RE_FFT_data_temp[30:0]	;
	
	
    	/***** fft_data_out *****/	
    	assign IM_FFT_data_temp = (m_axis_data_tvalid == 1'b1) ? m_axis_data_tdata[62:32]:'b0	;
    	assign RE_FFT_data_temp = (m_axis_data_tvalid == 1'b1) ? m_axis_data_tdata[30:0]:27'b0	;
    	assign POINT_FFT = (m_axis_data_tvalid == 1'b1) ? m_axis_data_tuser[13:0]:'b0		;
    	assign FFT_data_begin = m_axis_data_tvalid;
    	
    	/***** fft_to_ifft *****/
    	assign i_s_axis_config_tvalid = m_axis_data_tvalid	;
    	
    	// 数据发送逻辑 fft
	 always @(posedge fft_clk or negedge rest_n) begin
		if (!rest_n) begin
		    data_cnt <= 14'd0;
		    s_axis_data_tdata <= 32'd0;
		    s_axis_data_tvalid <= 1'b0;
		    s_axis_data_tlast <= 1'b0;
		    frame_started <= 1'b0;
		end 
		else if (s_axis_data_tready) 
		begin
		    // 开始发送数据（帧启动后）
		    /*
		    最后一个数据之前
		    */
		    if (data_cnt < 14'd16383)
		    begin
			// 输入数据有效		s_axis_data_tvalid;   
			// 输入数据就绪		s_axis_data_tready;
			// 输入数据结束标志	s_axis_data_tlast
			s_axis_data_tvalid <= 1'b1;
			s_axis_data_tlast <= 1'b0;
			// 数据拼接：虚部为0，实部来自DDS（12位有符号）
			// 数据拼接：可改用为adc
			s_axis_data_tdata <= {16'd0, data_wave[15:0]};
			data_cnt <= data_cnt + 1'b1;
		    end 
		    /*
		    最后一个数据
		    */
		    else if (data_cnt == 14'd16383) 
		    begin
			s_axis_data_tvalid <= 1'b1;
			s_axis_data_tlast <= 1'b1;  // 最后一个数据
			s_axis_data_tdata <= {16'd0, data_wave[15:0]};
			data_cnt <= data_cnt + 1'b1;
		    end 
		    else 
		    begin
			s_axis_data_tvalid <= 1'b0;
			s_axis_data_tlast <= 1'b0;
		    end
		end 
		else 
		begin
		    // 未准备好时保持数据
		    s_axis_data_tdata <= s_axis_data_tdata;
		    s_axis_data_tvalid <= s_axis_data_tvalid;
		    s_axis_data_tlast <= s_axis_data_tlast;
		end
	    end
    	
    	
    	ad9226	ad9226_fft
	(
	    	.clk		(adc_clk_main)	,      	// 输入时钟信号
	    	/*
	    	100MHz
	    	*/
	    	.rstn		(rest_n)	,    	// 复位信号，低电平有效
	    	.adc_in		(adc_in)	, 	// 假设这是ADC原始输入，对应前面的IO_data
	    	.adc_clk	(adc_clk)	, 	// 采样时钟，对应前面的clk_driver
	    	.data_wave 	(data_wave_adc)		// 最终输出，对应前面的ADC_Data
	);
    	
    	
    	adc_clk_main adc_clk_main_inst0
   	(
    		// Clock out ports	
    		.adc_clk_main	(adc_clk_main)	,     	// output adc_clk_main
    		.fft_clk	(fft_clk)	,     	// output fft_clk
    		// Status and control signals
    		.resetn		(rest)		, 	// input resetn
    		.locked		(locked)	,       // output locked
   		// Clock in ports
    		.sys_clk	(clk)      		// input sys_clk
	);
    	
    	fft_top	fft_top_inst0
	(
		/*****	clk rest_n *****/
		.clk_fft		(fft_clk)		,
		.rest_n			(rest_n)		,
		
		
		
		/*****	config	*****/
		.s_axis_config_tvalid	(1'b1)			,
		/*
		主机准备好信号
		通知IP核可从tdata读取配置数据
		*/
		.s_axis_config_tready	(s_axis_config_tready)	,
		/*
		FFT_IP准备好信号
		已准备好接收配置数据，高有效
		*/
		
		
		
		
		/****** s_axis_data *****/
		.s_axis_data_tdata	(s_axis_data_tdata)	,
		/*
		数据通道，并行输入
		[27:16][11:0]={IM,RE} 真实数据位
		[31:28][15:12] = 'd0  补0位
		*/
		.s_axis_data_tvalid	(s_axis_data_tvalid)	,
		/*
		通知IP核此时所有输入数据有效，每个上升沿读一次
		由上游主服务器(其他模块给出 eg: adc)所发出的信号表明其能够提供数据
		必须拉高 点数个周期才能拉低 建议数据采集就一直拉高
		*/
		.s_axis_data_tready	(s_axis_data_tready)	,
		/*
		由核心(FFT IP)使用以表示其已准备好接收数据
		IP核已准备好接收配置数据，高有效
		*/
		.s_axis_data_tlast	(s_axis_data_tlast)	,
		/*
		最后一个输入数据时，手动拉高（该数据被读取后，数据将不被读取）
		*/
		
		
		
		/****** m_axis_data *****/
		.m_axis_data_tdata	(m_axis_data_tdata)	,
		/*
		[58:32][26:0] = {IM，RE}
		*/
		.m_axis_data_tuser	(m_axis_data_tuser)	,
		/*
		[13:0]有效
		*/
		.m_axis_data_tvalid	(m_axis_data_tvalid)	,
		/*
		通知外部设备此时所有输出数据有效，每个上升沿出一个数据
		*/
		.m_axis_data_tready	(1'b1)			,
		/*
		外设已准备好接收配置数据，高有效
		*/
		.m_axis_data_tlast	(m_axis_data_tlast)	,
		/*
		最后一个输出数据时，自动拉高
		*/	
		
		
		/***** event_frame_started *****/
		.event_frame_started	(event_frame_started)
		/*
		转换开始信号
		*/	
			
   	);
    	
    	Hanning	Hanning_adc_fft
	(
		.clk		(clk)	,
    		.rest_n		(rest_n),
    		//input     wire    [9:0]data_in,
    
    		.data_out	(data_out_Hanning)
    	);
    	
    	ADC_Hanning ADC_Hanning_multipler_fft 
    	(
  		.CLK(fft_clk)		,  	// input wire CLK
  		.A(data_wave_adc[11:0])	,      	// input wire [11 : 0] A
  		.B(data_out_Hanning)	,      	// input wire [15 : 0] B
  		.P(Hanning_adc_out)      	// output wire [27 : 0] P
	);	
    	
    	
    	// 数据发送逻辑 ifft
	 always @(posedge fft_clk or negedge rest_n) begin
		if (!rest_n) begin
		    i_data_cnt <= 14'd0;
		    i_s_axis_data_tdata <= 32'd0;
		    i_s_axis_data_tvalid <= 1'b0;
		    i_s_axis_data_tlast <= 1'b0;
		end 
		else if (m_axis_data_tvalid && i_s_axis_data_tready) 
		begin
		    // 开始发送数据（帧启动后）
		    /*
		    最后一个数据之前
		    */
		    if (i_data_cnt < 14'd16383)
		    begin
			// 输入数据有效		s_axis_data_tvalid;   
			// 输入数据就绪		s_axis_data_tready;
			// 输入数据结束标志	s_axis_data_tlast
			i_s_axis_data_tvalid <= 1'b1;
			i_s_axis_data_tlast <= 1'b0;
			// 数据拼接：虚部为0，实部来自DDS（12位有符号）
			// 数据拼接：可改用为adc
			i_s_axis_data_tdata <= {m_axis_data_tdata[62:47], m_axis_data_tdata[30:15]};
			i_data_cnt <= i_data_cnt + 1'b1;
		    end 
		    /*
		    最后一个数据
		    */
		    else if (i_data_cnt == 14'd16383) 
		    begin
			i_s_axis_data_tvalid <= 1'b1;
			i_s_axis_data_tlast <= 1'b1;  // 最后一个数据
			i_s_axis_data_tdata <= {m_axis_data_tdata[62:47], m_axis_data_tdata[30:15]};
			i_data_cnt <= i_data_cnt + 1'b1;
		    end 
		    else 
		    begin
			i_s_axis_data_tvalid <= 1'b0;
			i_s_axis_data_tlast <= 1'b0;
		    end
		end 
		else 
		begin
		    // 未准备好时保持数据
		    i_s_axis_data_tdata <= i_s_axis_data_tdata;
		    i_s_axis_data_tvalid <= i_s_axis_data_tvalid;
		    i_s_axis_data_tlast <= i_s_axis_data_tlast;
		end
	    end
    	
    	
    	
    	
    	
    	ifft	ifft_inst0
	(
		.fft_clk			(fft_clk)	,
		.rest_n				(rest_n)	,
		/**** 输入数据有效 ****/	
		.i_s_axis_config_tvalid		(i_s_axis_config_tvalid)	,
		/**** IP准备接受 ****/
    		.i_s_axis_config_tready		(i_s_axis_config_tready)	,
		/**** 数据信号 ****/
    		.i_s_axis_data_tdata		(i_s_axis_data_tdata)		,
    		/**** 输入数据有效 ****/
    		.i_s_axis_data_tvalid		(i_s_axis_data_tvalid)		,
    		/**** ip可以接受数据 ****/	
    		.i_s_axis_data_tready		(i_s_axis_data_tready)		,
    		/****** m_axis_data *****/
		.i_m_axis_data_tdata		(i_m_axis_data_tdata)		,
		/*
		[62:32][30:0] = {IM，RE}
		*/
		/**** 输入最后一个数据 ****/
    		.i_s_axis_data_tlast		(i_s_axis_data_tlast)
    		
    	);
    	
    	
    	
    	
    	
    	
endmodule
