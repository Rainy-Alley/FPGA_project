`timescale 1ns / 1ps
module ad9226
	(
	    input 	wire		clk		,      	// 输入时钟信号
	    /*
	    100MHz
	    */
	    input 	wire		rstn		,    	// 复位信号，低电平有效
	    input 	wire	[12:0] 	adc_in		, 	// 假设这是ADC原始输入，对应前面的IO_data
	    output 	reg 		adc_clk		, 	// 采样时钟，对应前面的clk_driver
	    output 	reg 	[12:0] 	data_wave 		// 最终输出，对应前面的ADC_Data
	);
	
	`define clkOutPeriod  50 // 输出时钟周期为clk/clkOutPeriod 1Mhz采样
	
	reg [31:0] clkCnt; // 32位时钟计数器
	
	always @(posedge clk or negedge rstn) begin
	    if (!rstn) begin
		clkCnt <= 32'd0;
		adc_clk <= 1'd0;
		data_wave <= 13'd0;
	    end else begin
		if (clkCnt == (`clkOutPeriod - 1)) begin
		    clkCnt <= 32'd0;
		    adc_clk <= 1'd0;
		end else if (clkCnt == `clkOutPeriod / 2 - 1) begin
		    clkCnt <= clkCnt + 32'd1;
		    adc_clk <= 1'd1;
		    data_wave <= adc_in;
		end else begin
		    clkCnt <= clkCnt + 32'd1;
		end
	    end
	end
   	

endmodule