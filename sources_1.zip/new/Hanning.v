`timescale 1ns / 1ps
module Hanning
	(
		input 	wire    	clk	,
    		input 	wire    	rest_n	,
    		//input     wire    [9:0]data_in,
    
    		output 	wire    [15:0]	data_out
    	);
    	reg	[13:0]	addra	;
    	
    	always@(posedge clk or negedge rest_n)
         if(!rest_n) 
             addra <= 'd0;
         else
             addra <= addra + 1'b1;
    	
    	Hanning_Windows Hanning_rom_inst0
    	(
  		.clka(clk)	,    	// input wire clka
  		.addra(addra)	,  	// input wire [13 : 0] addra
  		.douta(data_out)  	// output wire [15 : 0] douta
	);
endmodule