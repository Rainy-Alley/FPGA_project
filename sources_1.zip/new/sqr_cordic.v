`timescale 1ns / 1ps
module sqr_cordic
	(
		input	wire		clk			,
		input	wire		rest_n			,
		input	wire		s_axis_cartesian_tvalid	,
		input	wire	[47:0]	data_sqr_in		,
		output 	wire	[24:0]	data_sqr_out		,
		output	wire		m_axis_dout_tvalid	
    	);
    	
    	/*
    	数据格式（Data Format）仅有无符号小数（Unsigned Fraction）
    	和无符号整形（Unsigned Integer）可选。
    	Square Root - Unsigned Fraction限制了输入的范围（0,2），
    	超出限制的输入会导致无意义输出
    	Square Root - Unsigned Fraction
    	X_IN: “0 000100000” => 0.000100000 => 1/16
    	X_OUT: “0 010000000” => 0.010000000 => 1/4
    	
    	Square Root - Unsigned Integer限制了输入的范围（0,2^输入宽度）
    	Square Root - Unsigned Integer
    	X_IN: “0000100000” => 32
    	X_OUT: “000110” => 6
    	
    	*/
    	wire	[47:0]	s_axis_cartesian_tdata				;
    	wire 	[31:0]	m_axis_dout_tdata				;
    	
    	assign s_axis_cartesian_tdata = {4'b0,data_sqr_in}		;
    	assign data_sqr_out = m_axis_dout_tdata[24:0]			;	
    	
    	cordic_sqr cordic_sqr_inst0 
    	(
  		.aclk(clk)						,       // input wire aclk
  		.s_axis_cartesian_tvalid(s_axis_cartesian_tvalid)	,  	// input wire s_axis_cartesian_tvalid
  		/*
  		输入数据有效
  		*/
  		.s_axis_cartesian_tdata(s_axis_cartesian_tdata)		,    	// input wire [15 : 0] s_axis_cartesian_tdata
  		.m_axis_dout_tvalid(m_axis_dout_tvalid)			,       // output wire m_axis_dout_tvalid
  		/*
  		输出数据有效
  		*/
  		.m_axis_dout_tdata(m_axis_dout_tdata)              		// output wire [15 : 0] m_axis_dout_tdata
	);
    	
    	
endmodule
