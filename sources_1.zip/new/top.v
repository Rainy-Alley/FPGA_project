`timescale 1ns / 1ps
module top
	(
		input 	wire		sys_clk	,
		input	wire		rest_n	,
		
		input 	wire	[12:0]	ADC	,
		
		output 	wire		adc_clk		
		/*
		31-16 整数
		15-0 小数
		*/

    	);
    	
		
	wire	[31:0]	rms_data	;
    	wire	[13:0]	ADC_in		;
    	
    	wire	[12:0]	data_wave	;
    	
    	assign 	ADC_in = {data_wave[11:0],2'b0};
    	
    	ila_0 your_instance_name (
	.clk(sys_clk), // input wire clk


	.probe0(adc_clk), // input wire [0:0]  probe0  
	.probe1(ADC), // input wire [12:0]  probe1 
	.probe2(rms_data) // input wire [31:0]  probe2
	);
    	
    	
    	wire	[31:0]	MS	;
    	
    	
    	AD9226_ReadModule	AD9226_ReadModule_inst0
    	(
    		.clk		(sys_clk)	,          	// 输入时钟信号
    		.rstn		(rest_n)	,         	// 复位信号，低电平有效
    		.adc_in		(ADC)		, 		// 假设这是ADC原始输入，对应前面的IO_data
    		.adc_clk	(adc_clk)	, 		// 采样时钟，对应前面的clk_driver
    		.data_wave	(data_wave) 			// 最终输出，对应前面的ADC_Data
	);
    	
    	
    	RMS #
	(
		.point('d1024)	
	)
	RMS_top
	(
		
		.clk		(sys_clk)	,
		.reset_n	(rest_n)	,
		.ADC_in		(ADC_in)	,
		                
		.MS	        (MS)
    	);
    	
    	
    	SQR_top	SQR_top_inst0
	(
		.clk		(sys_clk)	,
		.rest_n		(rest_n)	,
		.s_axis_a_tdata	(MS)		,
		
		.fix_data	(rms_data)		
    	);
    	
endmodule
