`timescale 1ns / 1ps
module top
	(
		input 	wire		clk		,
		input	wire		rest_n		,
		input 	wire	[11:0]	adc_data	,
		output 	wire	[13:0]	final_data

    	);
    	/*
    	adc
    	*/
    	wire	[31:0]	m_axis_result_tdata_multi_adc		;
	wire		m_axis_result_tvalid_adc_float		;
	// output wire m_axis_result_tvalid
	wire		m_axis_result_tready_adc_float = rest_n	;
	// input wire m_axis_result_tready
    	/*
    	adc
    	*/
    	
    	/*
    	I
    	*/
    	wire	[31:0]	m_axis_result_tdata_multi_adc_I	;
	wire		m_axis_result_tvalid_adc_float_I	;
	// output wire m_axis_result_tvalid
	wire		m_axis_result_tready_adc_float_I	;
	// input wire m_axis_result_tready
    	/*
    	I
    	*/
    	
    	/*
    	Q
    	*/
    	wire	[31:0]	m_axis_result_tdata_multi_adc_Q		;
	wire		m_axis_result_tvalid_adc_float_Q	;
	// output wire m_axis_result_tvalid
	wire		m_axis_result_tready_adc_float_Q	;
	// input wire m_axis_result_tready
    	/*
    	Q
    	*/
    	
    	
    	/*
	result_I
	*/
	wire		m_axis_result_tvalid_result_I	;  
	// output wire m_axis_result_tvalid
	wire		m_axis_result_tready_result_I	;
	// input wire m_axis_result_tready
	wire	[31:0]	m_axis_result_tdata_result_I	;    
	// output wire [31 : 0] m_axis_result_tdata
	/*
	result_I
	*/
	
	
	/*
	result_Q
	*/
	wire		m_axis_result_tvalid_result_Q	;  
	// output wire m_axis_result_tvalid
	wire		m_axis_result_tready_result_Q	;
	// input wire m_axis_result_tready
	wire	[31:0]	m_axis_result_tdata_result_Q	;	    
	// output wire [31 : 0] m_axis_result_tdata
	/*
	result_Q
	*/
    	
    	/*
    	float_dac_fix
    	*/
    	wire 		s_axis_a_tvalid_float_dac_fix	;           
	// input wire s_axis_a_tvalid           
	wire		s_axis_a_tready_float_dac_fix	;            
	// output wire s_axis_a_tready          
	wire 	[31:0]	s_axis_a_tdata_float_dac_fix	;              
	// input wire [31 : 0] s_axis_a_tdata
    	
    	assign m_axis_result_tdata_multi_adc_I 	= m_axis_result_tdata_multi_adc		;
    	assign m_axis_result_tvalid_adc_float_I = m_axis_result_tvalid_adc_float	;
    	// output wire m_axis_result_tvalid
    	assign m_axis_result_tready_adc_float_I = m_axis_result_tready_adc_float	;
    	// input wire m_axis_result_tready
    	
    	assign m_axis_result_tdata_multi_adc_Q  = m_axis_result_tdata_multi_adc		; 
    	assign m_axis_result_tvalid_adc_float_Q = m_axis_result_tvalid_adc_float 	;
    	// output wire m_axis_result_tvalid
    	assign m_axis_result_tready_adc_float_Q = m_axis_result_tready_adc_float 	;
    	// input wire m_axis_result_tready
    	
    	adc_float	adc_float_inst0
	(
		.clk				(clk),
		.rest_n				(rest_n),
		.adc_data			(adc_data),
		
		.m_axis_result_tdata_multi_adc	(m_axis_result_tdata_multi_adc),
		.m_axis_result_tvalid_adc_float	(m_axis_result_tvalid_adc_float),
		// output wire m_axis_result_tvalid
		.m_axis_result_tready_adc_float	(m_axis_result_tready_adc_float)
		// input wire m_axis_result_tready
    	);
    	
    	I_Q#
    	(
    		.F_WORD('d429496729)//4294967296(2^32)*i(频率)/10000000 载波频率
    	)
    	I_Q_inst0
	(
		.clk			(clk)		,
		.rest_n			(rest_n)	,
		.s_axis_a_tvalid_I	(m_axis_result_tvalid_adc_float_I),          
		// input wire s_axis_a_tvalid
	  	.s_axis_a_tready_I	(m_axis_result_tready_adc_float_I),            
	  	// output wire s_axis_a_tready
	        .adc_I			(m_axis_result_tdata_multi_adc_I),   
	  	// input wire [31 : 0] s_axis_a_tdata
	  	
		.s_axis_a_tvalid_Q	(m_axis_result_tvalid_adc_float_Q),          
		// input wire s_axis_a_tvalid
	  	.s_axis_a_tready_Q	(m_axis_result_tready_adc_float_Q),            
	  	// output wire s_axis_a_tready
	       	.adc_Q			(m_axis_result_tdata_multi_adc_Q),
	  	// input wire [31 : 0] s_axis_a_tdata
	  	
	  	/*
    		result_I
		*/
		.m_axis_result_tvalid_result_I	(m_axis_result_tvalid_result_I)	,  
		// output wire m_axis_result_tvalid
		.m_axis_result_tready_result_I	(m_axis_result_tready_result_I)	,
		// input wire m_axis_result_tready
		.m_axis_result_tdata_result_I	(m_axis_result_tdata_result_I)	,    
		// output wire [31 : 0] m_axis_result_tdata
		/*
		result_I
		*/
		
		
		/*
		result_Q
		*/
		.m_axis_result_tvalid_result_Q	(m_axis_result_tvalid_result_Q)	,  
		// output wire m_axis_result_tvalid
		.m_axis_result_tready_result_Q	(m_axis_result_tready_result_Q),
		// input wire m_axis_result_tready
		.m_axis_result_tdata_result_Q	(m_axis_result_tdata_result_Q)   
		// output wire [31 : 0] m_axis_result_tdata
		/*
		result_Q
		*/
		
    	);

    	
    	
    	low_filter	low_filter_I_Q
	(
		.clk				(clk),
		.rest_n				(rest_n),
		
		.s_axis_a_tvalid_I		(m_axis_result_tvalid_result_I),            
		// input wire s_axis_a_tvalid
  		.s_axis_a_tready_I		(m_axis_result_tready_result_I),            
  		// output wire s_axis_a_tready
		.data_I				(m_axis_result_tdata_result_I),
		
		.s_axis_a_tvalid_Q		(m_axis_result_tvalid_result_Q),            
		// input wire s_axis_a_tvalid
  		.s_axis_a_tready_Q		(m_axis_result_tready_result_Q),            
  		// output wire s_axis_a_tready
		.data_Q				(m_axis_result_tdata_result_Q),
		
		.m_axis_result_tvalid_sqr	(s_axis_a_tvalid_float_dac_fix),  
		// output wire m_axis_result_tvalid
  		.m_axis_result_tready_sqr	(s_axis_a_tready_float_dac_fix),  
  		// input wire m_axis_result_tready
		.filter_final_data		(s_axis_a_tdata_float_dac_fix)
    	);
    	
    	float_dac_fix	float_dac_fix_inst0
	(
		.clk					(clk),
		.s_axis_a_tvalid_float_dac_fix		(s_axis_a_tvalid_float_dac_fix),           
		// input wire s_axis_a_tvalid           
	  	.s_axis_a_tready_float_dac_fix		(s_axis_a_tready_float_dac_fix),            
	  	// output wire s_axis_a_tready          
	  	.s_axis_a_tdata_float_dac_fix		(s_axis_a_tdata_float_dac_fix),              
	  	// input wire [31 : 0] s_axis_a_tdata
	  	
	  	.m_axis_result_tvalid_fix_dac	(),  
	  	// output wire m_axis_result_tvalid
	  	.m_axis_result_tready_fix_dac	(rest_n),  
	  	// input wire m_axis_result_tready
	  	.m_axis_result_tdata_fix_dac	(final_data)	   
	  	// output wire [31 : 0] m_axis_result_tdata
	
    	);
    	
endmodule
