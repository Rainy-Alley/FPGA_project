`timescale 1ns / 1ps
module fix_to_float
	(
		input 	wire			clk			,
		input 	wire			rest_n			,
		input	wire	signed	[31:0]	s_axis_a_tdata		,
		/*
		fix_data
		*/
		input	wire			m_axis_result_tready	,
		/*
		后级能否接收
		*/
		output	wire			m_axis_result_tvalid	,
		/*
		数据是否ok
		*/
		output 	wire	signed	[31:0]	float_data		
		/*
		float_data
		*/
		
		
    	);
    	
    	wire	s_axis_a_tvalid		;
    	wire 	s_axis_a_tready		;
    		
    	assign 	s_axis_a_tvalid = 1'b1	;
    	
    	floating_point_fix_float floating_point_fix_float_inst0 
    	(
  		.aclk(clk),                                  // input wire aclk
  		.aresetn(rest_n),                            // input wire aresetn
  		.s_axis_a_tvalid(s_axis_a_tvalid),            // input wire s_axis_a_tvalid
  		.s_axis_a_tready(s_axis_a_tready),            // output wire s_axis_a_tready
  		.s_axis_a_tdata(s_axis_a_tdata),              // input wire [31 : 0] s_axis_a_tdata
  		.m_axis_result_tvalid(m_axis_result_tvalid),  // output wire m_axis_result_tvalid
  		.m_axis_result_tready(m_axis_result_tready),  // input wire m_axis_result_tready
  		.m_axis_result_tdata(float_data)    // output wire [31 : 0] m_axis_result_tdata
	);
endmodule
