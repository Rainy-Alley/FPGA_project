`timescale 1ns / 1ps
module fft_frq_Calculate
	(
		input	wire			clk		,
		input 	wire			rest		,
		input	wire		[12:0]	adc_in		,
		
		output 	wire 			adc_clk			
    	);
    	/**** FFt_点数 ****/
    	reg	[12:0]	fft_point		;
    	
    	/**** fft ***/
    	wire	[30:0]	IM_FFT_data		;
	wire	[30:0]	RE_FFT_data		;
	wire	[13:0]	POINT_FFT		;	
	wire		FFT_data_begin		;
	/*
    	FFT数据准备OK
    	*/
    	
	/*
	新时钟和复位 在PLL稳定后
	*/
	wire		rest_n			;
	wire 		fft_clk			;
	
	/**** cordic_sqr ****/
	wire	[60:0]	Sum_of_squares		;
	/*
	RE IM 平方和
	*/
    	wire		s_axis_cartesian_tvalid	;
    	/*
    	外部数据准备OK
    	*/
	wire	[47:0]	data_sqr_in		;
	wire	[24:0]	data_sqr_out		;
	wire		m_axis_dout_tvalid	;
	/*
	输出数据OK
	*/
	
	/**** 归一化单边频谱 ****/
	wire	[11:0]	Normalization_data	;
	
    	
    	assign s_axis_cartesian_tvalid = FFT_data_begin	;
    	/**** 平方和 ****/ 
    	assign Sum_of_squares = ((FFT_data_begin == 1'b1) && ((POINT_FFT > 'd6) && (POINT_FFT < 'd8193 )))?((IM_FFT_data * IM_FFT_data) + (RE_FFT_data * RE_FFT_data)):'d0;
	/**** 平方和截取 ****/ 
	assign data_sqr_in = Sum_of_squares[60:13]	;
	
	/**** 归一化单边频谱计算 ****/ 
	assign Normalization_data = data_sqr_out >> 'd13;
	always @(posedge fft_clk or negedge rest_n)
	if(!rest_n)
	begin
		fft_point <= 'd0	;
	end
	else if(m_axis_dout_tvalid)
	begin
		fft_point <= fft_point +1'b1;
	end
	else
	begin
		fft_point <= 'd0	;
	end
	
	
    	sqr_cordic	sqr_cordic_fft
	(
		.clk				(fft_clk)			,
		.rest_n				(rest_n)			,
		.s_axis_cartesian_tvalid	(s_axis_cartesian_tvalid)	,
		.data_sqr_in			(data_sqr_in)			,
		.data_sqr_out			(data_sqr_out)			,
		.m_axis_dout_tvalid		(m_axis_dout_tvalid)
    	);
    	
    	ADC_fft	ADC_fft_calculate
	(
		.clk		(clk)		,
		.rest		(rest)		,
		.adc_in		(adc_in)	,
		/**** rest_n - clk_PLL ****/
		.rest_n		(rest_n)	,
		.fft_clk	(fft_clk)	,
			
		.adc_clk	(adc_clk)	,
		.IM_FFT_data	(IM_FFT_data)	,
		.RE_FFT_data	(RE_FFT_data)	,
		.POINT_FFT	(POINT_FFT)	,
		.FFT_data_begin	(FFT_data_begin)	
		
    	);
    	
    	
endmodule
