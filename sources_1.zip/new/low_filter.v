`timescale 1ns / 1ps
module low_filter
	(
		input 	wire		clk			,
		input 	wire		rest_n			,
		
		input 	wire		s_axis_a_tvalid_I	,            
		// input wire s_axis_a_tvalid
  		output 	wire		s_axis_a_tready_I	,            
  		// output wire s_axis_a_tready
		input 	wire	[31:0]	data_I			,
		
		input 	wire		s_axis_a_tvalid_Q	,            
		// input wire s_axis_a_tvalid
  		output 	wire		s_axis_a_tready_Q	,            
  		// output wire s_axis_a_tready
		input 	wire	[31:0]	data_Q			,
		
		output 	wire		m_axis_result_tvalid_sqr,  
		// output wire m_axis_result_tvalid
  		input	wire		m_axis_result_tready_sqr,  
  		// input wire m_axis_result_tready
		output 	wire	[31:0]	filter_final_data
    	);
    	
    	
    	/*
    	I_fix
    	*/
    	wire			m_axis_result_tvalid_I		;  
    	// output wire m_axis_result_tvalid
  	wire			m_axis_result_tready_I		; 
  	// input wire m_axis_result_tready	
  	wire	signed	[31:0]	m_axis_result_tdata_I		;
  	// output wire [31 : 0] m_axis_result_tdata
    	/*
    	I_fix
    	*/
    	
    	/*
    	result_I
    	*/
    	wire			m_axis_result_tvalid_result_I	;  
    	// output wire m_axis_result_tvalid
  	wire			m_axis_result_tready_result_I	;  
  	// input wire m_axis_result_tready
 	wire		[31:0]	m_axis_result_tdata_result_I	;    
 	// output wire [31 : 0] m_axis_result_tdata
    	/*
    	result_I
    	*/
    	
    	wire			m_axis_data_tvalid_I		;  
    	// output wire m_axis_data_tvalid
  	wire			m_axis_data_tready_I		;	 
  	// input wire m_axis_data_tready
  	wire		[55:0]	m_axis_data_tdata_I		;   
  	// output wire [55 : 0] m_axis_data_tdata
	
    	
    	/*
    	I*I
    	*/
    	wire			m_axis_result_tvalid_I_2;  
    	// output wire m_axis_result_tvalid
  	wire			m_axis_result_tready_I_2;
  	// input wire m_axis_result_tready
  	wire 		[31:0]	m_axis_result_tdata_I_2	;  
  	// output wire [31 : 0] m_axis_result_tdata
	/*
	I*I
	*/
    	
    	
    	/*
    	Q_fix
    	*/
    	wire			m_axis_result_tvalid_Q		;  
    	// output wire m_axis_result_tvalid
  	wire			m_axis_result_tready_Q		; 
  	// input wire m_axis_result_tready	
  	wire	signed	[31:0]	m_axis_result_tdata_Q		;
  	// output wire [31 : 0] m_axis_result_tdata
    	/*
    	Q_fix
    	*/
    	
    	/*
    	result_Q
    	*/
    	wire			m_axis_result_tvalid_result_Q	;  
    	// output wire m_axis_result_tvalid
  	wire			m_axis_result_tready_result_Q	;  
  	// input wire m_axis_result_tready
 	wire		[31:0]	m_axis_result_tdata_result_Q	;    
 	// output wire [31 : 0] m_axis_result_tdata
    	/*
    	result_Q
    	*/
    	
    	wire			m_axis_data_tvalid_Q		;  
    	// output wire m_axis_data_tvalid
  	wire			m_axis_data_tready_Q		;	 
  	// input wire m_axis_data_tready
  	wire		[55:0]	m_axis_data_tdata_Q		;   
  	// output wire [55 : 0] m_axis_data_tdata
	
    	
    	/*
    	Q*Q
    	*/
    	wire			m_axis_result_tvalid_Q_2;  
    	// output wire m_axis_result_tvalid
  	wire			m_axis_result_tready_Q_2;
  	// input wire m_axis_result_tready
  	wire 		[31:0]	m_axis_result_tdata_Q_2	;  
  	// output wire [31 : 0] m_axis_result_tdata
	/*
	Q*Q
	*/
    	
    	/*
    	sum
    	*/
    	wire			m_axis_result_tvalid_sum;
    	 // output wire m_axis_result_tvalid
  	wire			m_axis_result_tready_sum;	
  	// input wire m_axis_result_tready
  	wire		[31:0]	m_axis_result_tdata_sum	;
  	// output wire [31 : 0] m_axis_result_tdata
	
    	/*
    	sum
    	*/
    	
    	
    	/*
    	I
    	*/
    	floating_point_float_fix floating_point_float_fix_I 
    	(
  		.aclk(clk),                                  // input wire aclk
  		.s_axis_a_tvalid(s_axis_a_tvalid_I),            // input wire s_axis_a_tvalid
  		.s_axis_a_tready(s_axis_a_tready_I),            // output wire s_axis_a_tready
  		.s_axis_a_tdata(data_I),              // input wire [31 : 0] s_axis_a_tdata
  		
  		.m_axis_result_tvalid(m_axis_result_tvalid_I),  // output wire m_axis_result_tvalid
  		.m_axis_result_tready(m_axis_result_tready_I),  // input wire m_axis_result_tready
  		.m_axis_result_tdata(m_axis_result_tdata_I)    // output wire [31 : 0] m_axis_result_tdata
	);
    	
    	
    	fir_low fir_low_I 
    	(
  		.aclk(clk),                              // input wire aclk
  		.s_axis_data_tvalid(m_axis_result_tvalid_I),  // input wire s_axis_data_tvalid
  		.s_axis_data_tready(m_axis_result_tready_I),  // output wire s_axis_data_tready
  		.s_axis_data_tdata(m_axis_result_tdata_I),    // input wire [31 : 0] s_axis_data_tdata
  		
  		.m_axis_data_tvalid(m_axis_data_tvalid_I),  // output wire m_axis_data_tvalid
  		.m_axis_data_tready(m_axis_data_tready_I),  // input wire m_axis_data_tready
  		.m_axis_data_tdata(m_axis_data_tdata_I)    // output wire [55 : 0] m_axis_data_tdata
	);
    	
    	
    	floating_point_fir_fix_loat floating_point_fir_fix_loat_I 
    	(
  		.aclk(clk),                                  // input wire aclk
  		.s_axis_a_tvalid(m_axis_data_tvalid_I),            // input wire s_axis_a_tvalid
  		.s_axis_a_tready(m_axis_data_tready_I),            // output wire s_axis_a_tready
  		.s_axis_a_tdata(m_axis_data_tdata_I[49:0]),              // input wire [55 : 0] s_axis_a_tdata
  		
  		.m_axis_result_tvalid(m_axis_result_tvalid_result_I),  // output wire m_axis_result_tvalid
  		.m_axis_result_tready(m_axis_result_tready_result_I),  // input wire m_axis_result_tready
 		.m_axis_result_tdata(m_axis_result_tdata_result_I)    // output wire [31 : 0] m_axis_result_tdata
	);
	
	floating_multi floating_multi_I 
    	(
  		.aclk(clk),                                  // input wire aclk
  		.s_axis_a_tvalid(m_axis_result_tvalid_result_I),            // input wire s_axis_a_tvalid
  		.s_axis_a_tready(m_axis_result_tready_result_I),            // output wire s_axis_a_tready
  		.s_axis_a_tdata(m_axis_result_tdata_result_I),              // input wire [31 : 0] s_axis_a_tdata
  		
  		.s_axis_b_tvalid(m_axis_result_tvalid_result_I),            // input wire s_axis_b_tvalid
  		.s_axis_b_tready(m_axis_result_tready_result_I),            // output wire s_axis_b_tready
  		.s_axis_b_tdata(m_axis_result_tdata_result_I),              // input wire [31 : 0] s_axis_b_tdata
  		
  		.m_axis_result_tvalid(m_axis_result_tvalid_I_2),  // output wire m_axis_result_tvalid
  		.m_axis_result_tready(m_axis_result_tready_I_2),  // input wire m_axis_result_tready
  		.m_axis_result_tdata(m_axis_result_tdata_I_2)    // output wire [31 : 0] m_axis_result_tdata
	);
	
	/*
    	I
    	*/
    	
    	
    	
    	/*
    	Q
    	*/
	floating_point_float_fix floating_point_float_fix_Q 
    	(
  		.aclk(clk),                                  // input wire aclk
  		.s_axis_a_tvalid(s_axis_a_tvalid_Q),            // input wire s_axis_a_tvalid
  		.s_axis_a_tready(s_axis_a_tready_Q),            // output wire s_axis_a_tready
  		.s_axis_a_tdata(data_Q),              // input wire [31 : 0] s_axis_a_tdata
  		
  		.m_axis_result_tvalid(m_axis_result_tvalid_Q),  // output wire m_axis_result_tvalid
  		.m_axis_result_tready(m_axis_result_tready_Q),  // input wire m_axis_result_tready
  		.m_axis_result_tdata(m_axis_result_tdata_Q)    // output wire [31 : 0] m_axis_result_tdata
	);
    	
    	
    	fir_low fir_low_Q 
    	(
  		.aclk(clk),                              // input wire aclk
  		.s_axis_data_tvalid(m_axis_result_tvalid_Q),  // input wire s_axis_data_tvalid
  		.s_axis_data_tready(m_axis_result_tready_Q),  // output wire s_axis_data_tready
  		.s_axis_data_tdata(m_axis_result_tdata_Q),    // input wire [31 : 0] s_axis_data_tdata
  		
  		.m_axis_data_tvalid(m_axis_data_tvalid_Q),  // output wire m_axis_data_tvalid
  		.m_axis_data_tready(m_axis_data_tready_Q),  // input wire m_axis_data_tready
  		.m_axis_data_tdata(m_axis_data_tdata_Q)    // output wire [55 : 0] m_axis_data_tdata
	);
    	
    	
    	floating_point_fir_fix_loat floating_point_fir_fix_loat_Q 
    	(
  		.aclk(clk),                                  // input wire aclk
  		.s_axis_a_tvalid(m_axis_data_tvalid_Q),            // input wire s_axis_a_tvalid
  		.s_axis_a_tready(m_axis_data_tready_Q),            // output wire s_axis_a_tready
  		.s_axis_a_tdata(m_axis_data_tdata_Q[49:0]),              // input wire [55 : 0] s_axis_a_tdata
  		
  		.m_axis_result_tvalid(m_axis_result_tvalid_result_Q),  // output wire m_axis_result_tvalid
  		.m_axis_result_tready(m_axis_result_tready_result_Q),  // input wire m_axis_result_tready
 		.m_axis_result_tdata(m_axis_result_tdata_result_Q)    // output wire [31 : 0] m_axis_result_tdata
	);
	
	
	floating_multi floating_multi_Q 
    	(
  		.aclk(clk),                                  // input wire aclk
  		.s_axis_a_tvalid(m_axis_result_tvalid_result_Q),            // input wire s_axis_a_tvalid
  		.s_axis_a_tready(m_axis_result_tready_result_Q),            // output wire s_axis_a_tready
  		.s_axis_a_tdata(m_axis_result_tdata_result_Q),              // input wire [31 : 0] s_axis_a_tdata
  		
  		.s_axis_b_tvalid(m_axis_result_tvalid_result_Q),            // input wire s_axis_b_tvalid
  		.s_axis_b_tready(m_axis_result_tready_result_Q),            // output wire s_axis_b_tready
  		.s_axis_b_tdata(m_axis_result_tdata_result_Q),              // input wire [31 : 0] s_axis_b_tdata
  		
  		.m_axis_result_tvalid(m_axis_result_tvalid_Q_2),  // output wire m_axis_result_tvalid
  		.m_axis_result_tready(m_axis_result_tready_Q_2),  // input wire m_axis_result_tready
  		.m_axis_result_tdata(m_axis_result_tdata_Q_2)    // output wire [31 : 0] m_axis_result_tdata
	);
	
    	/*
    	Q
    	*/
    	
    	
    	/*
    	sum
    	*/
    	floating_point_sum floating_point_sum_I_Q 
    	(
  		.aclk(clk),                                  // input wire aclk
  		.s_axis_a_tvalid(m_axis_result_tvalid_I_2),            // input wire s_axis_a_tvalid
  		.s_axis_a_tready(m_axis_result_tready_I_2),            // output wire s_axis_a_tready
  		.s_axis_a_tdata(m_axis_result_tdata_I_2),              // input wire [31 : 0] s_axis_a_tdata
 		
 		.s_axis_b_tvalid(m_axis_result_tvalid_Q_2),            // input wire s_axis_b_tvalid
 		.s_axis_b_tready(m_axis_result_tready_Q_2),            // output wire s_axis_b_tready
  		.s_axis_b_tdata(m_axis_result_tdata_Q_2),              // input wire [31 : 0] s_axis_b_tdata
 		
 		.m_axis_result_tvalid(m_axis_result_tvalid_sum),  // output wire m_axis_result_tvalid
  		.m_axis_result_tready(m_axis_result_tready_sum),  // input wire m_axis_result_tready
  		.m_axis_result_tdata(m_axis_result_tdata_sum)    // output wire [31 : 0] m_axis_result_tdata
	);
    	/*
    	sum
    	*/
    	
    	
    	/*
    	sqrt
    	*/
    	floating_point_sqrt floating_point_sqrt 
    	(
  		.aclk(clk),                                  // input wire aclk
  		.s_axis_a_tvalid(m_axis_result_tvalid_sum),            // input wire s_axis_a_tvalid
  		.s_axis_a_tready(m_axis_result_tready_sum),            // output wire s_axis_a_tready
  		.s_axis_a_tdata(m_axis_result_tdata_sum),              // input wire [31 : 0] s_axis_a_tdata
 		
 		.m_axis_result_tvalid(m_axis_result_tvalid_sqr),  // output wire m_axis_result_tvalid
  		.m_axis_result_tready(m_axis_result_tready_sqr),  // input wire m_axis_result_tready
  		.m_axis_result_tdata(filter_final_data)    // output wire [31 : 0] m_axis_result_tdata
	);
    	
    	/*
    	sqrt
    	*/
    	
endmodule
