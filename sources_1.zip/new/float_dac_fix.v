`timescale 1ns / 1ps
module float_dac_fix
	(
		input	wire		clk				,
		input 	wire		s_axis_a_tvalid_float_dac_fix	,           
		// input wire s_axis_a_tvalid
	  	output 	wire		s_axis_a_tready_float_dac_fix	,            
	  	// output wire s_axis_a_tready
	  	input 	wire	[31:0]	s_axis_a_tdata_float_dac_fix	,              
	  	// input wire [31 : 0] s_axis_a_tdata
	  	
	  	output 	wire		m_axis_result_tvalid_fix_dac	,  
	  	// output wire m_axis_result_tvalid
  		output 	wire		m_axis_result_tready_fix_dac	,  
  		// input wire m_axis_result_tready
  		output 	wire	[13:0]	m_axis_result_tdata_fix_dac    
  		// output wire [15 : 0] m_axis_result_tdata
	
	
    	);
    	
    	wire		m_axis_result_tvalid_float_dac_fix		;  
	// output wire m_axis_result_tvalid
	wire		m_axis_result_tready_float_dac_fix		; 
	// input wire m_axis_result_tready
	wire	[31:0]	m_axis_result_tdata_float_dac_fix		;	   
	// output wire [31 : 0] m_axis_result_tdata
    	wire	[15:0]	m_axis_result_tdata_dac_fix			; 
    	 
    	assign 	m_axis_result_tdata_fix_dac = (m_axis_result_tvalid_fix_dac == 1'b1) ? m_axis_result_tdata_dac_fix[13:0] : 'd8192;
    	 
    	floating_point_divde floating_point_divde_float_dac_fix 
    	(
	  	.aclk(clk),                                  // input wire aclk
	  	.s_axis_a_tvalid(s_axis_a_tvalid_float_dac_fix),            // input wire s_axis_a_tvalid
	  	.s_axis_a_tready(s_axis_a_tready_float_dac_fix),            // output wire s_axis_a_tready
	  	.s_axis_a_tdata(s_axis_a_tdata_float_dac_fix),              // input wire [31 : 0] s_axis_a_tdata
	  
	  	.s_axis_b_tvalid(1'b1),            // input wire s_axis_b_tvalid
	  	.s_axis_b_tready(s_axis_b_tready),            // output wire s_axis_b_tready
	  	.s_axis_b_tdata(32'h3A200000),              // input wire [31 : 0] s_axis_b_tdata
	 
	  	.m_axis_result_tvalid(m_axis_result_tvalid_float_dac_fix),  // output wire m_axis_result_tvalid
	  	.m_axis_result_tready(m_axis_result_tready_float_dac_fix),  // input wire m_axis_result_tready
	  	.m_axis_result_tdata(m_axis_result_tdata_float_dac_fix)    // output wire [31 : 0] m_axis_result_tdata
	);
    	
    	floating_point_dac_fix floating_point_dac_fix_inst0    	
    	(
  		.aclk(clk),                                  // input wire aclk
  		.s_axis_a_tvalid(m_axis_result_tvalid_float_dac_fix),            // input wire s_axis_a_tvalid
  		.s_axis_a_tready(m_axis_result_tready_float_dac_fix),            // output wire s_axis_a_tready
  		.s_axis_a_tdata(m_axis_result_tdata_float_dac_fix),              // input wire [31 : 0] s_axis_a_tdata
  		
  		.m_axis_result_tvalid(m_axis_result_tvalid_fix_dac),  // output wire m_axis_result_tvalid
  		.m_axis_result_tready(m_axis_result_tready_fix_dac),  // input wire m_axis_result_tready
  		.m_axis_result_tdata(m_axis_result_tdata_dac_fix)    // output wire [15 : 0] m_axis_result_tdata
	);
    	
endmodule
