`timescale 1ns / 1ps
module float_to_fix
	(
		input 	wire			clk				,
		input 	wire			rest_n				,
		/*
		数据是否有效
		*/
		input	wire			s_axis_a_tvalid_float_fix	,
		
		input	wire	signed	[31:0]	float_data			,
		
		/*
		数据是否可以输入
		*/
		output 	wire			s_axis_a_tready_float_fix	,
		
		output 	wire			m_axis_result_tvalid		,
		output 	wire 	signed	[31:0]	fix_data			
		
    	);
    	/*
    	后级是否可以接受
    	*/
    	wire	m_axis_result_tready		;
    	
    	assign 	m_axis_result_tready = 1'b1	;
    	
  	floating_point_0 float_fix 
  	(
  		.aclk(clk),                                  // input wire aclk
  		.aresetn(rest_n),                            // input wire aresetn
  		.s_axis_a_tvalid(s_axis_a_tvalid_float_fix),            // input wire s_axis_a_tvalid
  		.s_axis_a_tready(s_axis_a_tready_float_fix),            // output wire s_axis_a_tready
	  	.s_axis_a_tdata(float_data),              // input wire [31 : 0] s_axis_a_tdata
	  	.m_axis_result_tvalid(m_axis_result_tvalid),  // output wire m_axis_result_tvalid
  		.m_axis_result_tready(m_axis_result_tready),  // input wire m_axis_result_tready
  		.m_axis_result_tdata(fix_data)    // output wire [31 : 0] m_axis_result_tdata
	);  	
    	
endmodule
