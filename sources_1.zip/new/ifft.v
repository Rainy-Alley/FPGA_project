`timescale 1ns / 1ps
module ifft
	(
		input	wire			fft_clk			,
		input	wire			rest_n			,
		/**** 输入数据有效 ****/	
		input	wire			i_s_axis_config_tvalid	,
		/**** IP准备接受 ****/
    		input	wire			i_s_axis_config_tready	,
		/**** 数据信号 ****/
    		input 	wire	signed	[31:0]	i_s_axis_data_tdata	,
    		/**** 输入数据有效 ****/
    		input	wire			i_s_axis_data_tvalid	,
    		/**** 可以接受数据 ****/
    		input	wire			i_s_axis_data_tready	,
    		/****** m_axis_data *****/
		input 	wire	signed	[62:0]	i_m_axis_data_tdata	,
		/*
		[62:32][30:0] = {IM，RE}
		*/
		/**** 输入最后一个数据 ****/
    		input	wire 			i_s_axis_data_tlast	
    		
    	);
    	
	wire			i_m_axis_data_tuser	;
	/*
	[13:0]有效
	*/
	wire			i_m_axis_data_tvalid	;	
	/*
	通知外部设备此时所有输出数据有效，每个上升沿出一个数据
	*/
	wire			i_m_axis_data_tready	;
	/*
	外设已准备好接收配置数据，高有效
	*/
	wire			i_m_axis_data_tlast	;
	/*
	最后一个输出数据时，自动拉高
	*/	
		
		
	/***** event_frame_started *****/
	wire			i_event_frame_started	;
	/*
	转换开始信号
	*/
    	
    	
    	
    	
    	
    	ifft_top	ifft_top_inst0
	(
		/*****	clk rest_n *****/
		.clk_fft		(fft_clk)			,
		.rest_n			(rest_n)			,
		
		
		
		/*****	config	*****/
		.s_axis_config_tvalid	(i_s_axis_config_tvalid)	,
		/*
		主机准备好信号
		通知IP核可从tdata读取配置数据
		*/
		.s_axis_config_tready	(i_s_axis_config_tready)	,
		/*
		FFT_IP准备好信号
		已准备好接收配置数据，高有效
		*/
		
		
		
		
		/****** s_axis_data *****/
		.s_axis_data_tdata	(i_s_axis_data_tdata)		,
		/*
		数据通道，并行输入
		[31:16][15:0]={IM,RE} 真实数据位
		*/
		.s_axis_data_tvalid	(i_s_axis_data_tvalid)		,
		/*
		通知IP核此时所有输入数据有效，每个上升沿读一次
		由上游主服务器(其他模块给出 eg: adc)所发出的信号表明其能够提供数据
		必须拉高 点数个周期才能拉低 建议数据采集就一直拉高
		*/
		.s_axis_data_tready	(i_s_axis_data_tready)		,
		/*
		由核心(FFT IP)使用以表示其已准备好接收数据
		IP核已准备好接收配置数据，高有效
		*/
		.s_axis_data_tlast	(i_s_axis_data_tlast)		,
		/*
		最后一个输入数据时，手动拉高（该数据被读取后，数据将不被读取）
		*/
		
		
		
		/****** m_axis_data *****/
		.m_axis_data_tdata	(i_m_axis_data_tdata)		,
		/*
		[58:32][26:0] = {IM，RE}
		*/
		.m_axis_data_tuser	(i_m_axis_data_tuser)		,
		/*
		[13:0]有效
		*/
		.m_axis_data_tvalid	(i_m_axis_data_tvalid)		,
		/*
		通知外部设备此时所有输出数据有效，每个上升沿出一个数据
		*/
		.m_axis_data_tready	(1'b1)				,
		/*
		外设已准备好接收配置数据，高有效
		*/
		.m_axis_data_tlast	(i_m_axis_data_tlast)		,
		/*
		最后一个输出数据时，自动拉高
		*/	
		
		
		/***** event_frame_started *****/
		.event_frame_started	(i_event_frame_started)
		/*
		转换开始信号
		*/	
			
   	);
    	
    	
endmodule
