`timescale 1ns / 1ps
module float_cos#
	(
		parameter F_WORD = 32'd429496729,
		parameter P_WORD = 'd2048
	)
	(
		input 	wire		clk			,
		input 	wire 		rest_n			,
		output 	wire 		m_axis_result_tvalid	,
    		// output wire m_axis_result_tvalid
  		input 	wire 		m_axis_result_tready	,
  		// input wire m_axis_result_tready
  		output 	wire 	[31:0]	m_axis_result_tdata	
  		// output wire [31 : 0] m_axis_result_tdata	
	
    	);
    	
    	/*
    	dds_cos
    	*/
    	wire	signed	[11:0]	rom_data_cos_signed		;
    	wire 		[11:0]	rom_data_cos			;
    	
    	assign 	rom_data_cos_signed = rom_data_cos - 'd2047	;
    	/*
    	dds_cos
    	*/
    	
    	
    	/*
    	divde
    	*/
    	wire 		s_axis_a_tvalid		;            
    	// input wire s_axis_a_tvalid
  	wire		s_axis_a_tready		;            
  	// output wire s_axis_a_tready
  	wire	[31:0]	s_axis_a_tdata		;              
  	// input wire [31 : 0] s_axis_a_tdata
  	
  	wire 		s_axis_b_tvalid	= 1'b1	;            
    	// input wire s_axis_b_tvalid
  	wire		s_axis_b_tready		;	            
  	// output wire s_axis_b_tready
  	wire		s_axis_b_tdata		;              
  	// input wire [31 : 0] s_axis_b_tdata
	
    	
    	/*
    	divde
    	*/
    	dds_cos#
    	(
    		.F_WORD(F_WORD),
    		.P_WORD(P_WORD)
    	)
    	dds_cos_inst0
	(
    		.clk		(clk)	,
    		.rest_n		(rest_n)	,	
    		//input     wire    [9:0]data_in,
    		.rom_data_cos	(rom_data_cos)	
    		
    	);
    	
    	fix_point_ip fix_point_ip_cos
	(
  		.aclk(clk),                                  // input wire aclk
  		.s_axis_a_tvalid(rest_n),            // input wire s_axis_a_tvalid
  		.s_axis_a_tready(s_axis_a_tready),            // output wire s_axis_a_tready
  		.s_axis_a_tdata(rom_data_cos_signed),              // input wire [15 : 0] s_axis_a_tdata
  		
  		.m_axis_result_tvalid(s_axis_a_tvalid),  // output wire m_axis_result_tvalid
  		.m_axis_result_tready(s_axis_a_tready),  // input wire m_axis_result_tready
  		.m_axis_result_tdata(s_axis_a_tdata)    // output wire [31 : 0] m_axis_result_tdata
	);
    	
    	
    	/*
    	result = A/B
    	*/
    	
    	floating_point_divde floating_point_divde_cos 
    	(
  		.aclk(clk),                                  // input wire aclk
  		.s_axis_a_tvalid(s_axis_a_tvalid),            // input wire s_axis_a_tvalid
  		.s_axis_a_tready(s_axis_a_tready),            // output wire s_axis_a_tready
  		.s_axis_a_tdata(s_axis_a_tdata),              // input wire [31 : 0] s_axis_a_tdata
  		
  		.s_axis_b_tvalid(s_axis_b_tvalid),            // input wire s_axis_b_tvalid
  		.s_axis_b_tready(s_axis_b_tready),            // output wire s_axis_b_tready
  		.s_axis_b_tdata('h44FFE000),              // input wire [31 : 0] s_axis_b_tdata
  		
  		.m_axis_result_tvalid(m_axis_result_tvalid),  // output wire m_axis_result_tvalid
  		.m_axis_result_tready(m_axis_result_tready),  // input wire m_axis_result_tready
  		.m_axis_result_tdata(m_axis_result_tdata)    // output wire [31 : 0] m_axis_result_tdata
	);
endmodule
