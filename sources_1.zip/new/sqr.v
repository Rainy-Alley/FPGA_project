`timescale 1ns / 1ps
module sqr
	(
		input	wire		clk			,
		input 	wire		rest_n			,
		/*
		输入数据有效
		*/
		input 	wire		s_axis_a_tvalid_sqr	,
		/*
		可以输出数据
		*/
		output 	wire 		s_axis_a_tready_sqr	,
		
		input 	wire	signed	[31:0]	sqr_in_data	,
		
		/*
		输出数据有效
		*/
		output 	wire		m_axis_result_tvalid_sqr,
		
		/*
		下一级可以接受数据
		*/
		input	wire		m_axis_result_tready_sqr,
		
		output 	wire	signed	[31:0]	sqr_out_data	
		
    	);
    	
    	
    	sqr_float sqr_float_inst0 
    	(
  		.aclk(clk),                                  // input wire aclk
  		.aresetn(rest_n),                            // input wire aresetn
  		.s_axis_a_tvalid(s_axis_a_tvalid_sqr),            // input wire s_axis_a_tvalid
  		.s_axis_a_tready(s_axis_a_tready_sqr),            // output wire s_axis_a_tready
  		.s_axis_a_tdata(sqr_in_data),              // input wire [31 : 0] s_axis_a_tdata
  		.m_axis_result_tvalid(m_axis_result_tvalid_sqr),  // output wire m_axis_result_tvalid
  		.m_axis_result_tready(m_axis_result_tready_sqr),  // input wire m_axis_result_tready
  		.m_axis_result_tdata(sqr_out_data)    // output wire [31 : 0] m_axis_result_tdata
	);
    	
    	
    	
    	
endmodule
