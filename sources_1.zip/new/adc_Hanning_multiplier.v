`timescale 1ns / 1ps
module adc_Hanning_multiplier
	(
		input 	wire		clk		,      	// 输入时钟信号
	    	/*
	    	100MHz
	    	*/
	    	input 	wire		rstn		,    	// 复位信号，低电平有效
	    	input 	wire	[12:0] 	adc_in		, 	// 假设这是ADC原始输入，对应前面的IO_data
	    	output 	wire 		adc_clk		, 	// 采样时钟，对应前面的clk_driver
	    	output 	wire	[27:0]	Hanning_adc_out

    	);
    	
    	wire 	[12:0] 	data_wave_adc 	;		// 最终输出，对应前面的ADC_Data
    	wire	[15:0]	data_out_Hanning;
    	
    	
    	ad9226	ad9226_Hanning_multiplier
	(
	    .clk	(clk)		,      	// 输入时钟信号
	    /*
	    100MHz
	    */
	    .rstn	(rstn)		,    	// 复位信号，低电平有效
	    .adc_in	(adc_in)	, 	// 假设这是ADC原始输入，对应前面的IO_data
	    .adc_clk	(adc_clk)	, 	// 采样时钟，对应前面的clk_driver
	    .data_wave 	(data_wave_adc)		// 最终输出，对应前面的ADC_Data
	);
    	
    	Hanning	Hanning_adc
	(
		.clk		(clk)	,
    		.rest_n		(rstn)	,
    		//input     wire    [9:0]data_in,
    
    		.data_out	(data_out_Hanning)
    	);
    	
    	ADC_Hanning ADC_Hanning_multipler 
    	(
  		.CLK(clk)		,  	// input wire CLK
  		.A(data_wave_adc[11:0])	,      	// input wire [11 : 0] A
  		.B(data_out_Hanning)	,      	// input wire [15 : 0] B
  		.P(Hanning_adc_out)      	// output wire [12 : 0] P
	);
    	
endmodule
