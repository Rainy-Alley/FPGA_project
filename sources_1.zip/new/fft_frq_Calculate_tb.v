`timescale 1ns / 1ps
module fft_frq_Calculate_tb();
	
	fft_frq_Calculate	fft_frq_Calculate_tb
	(
		.clk		(clk)		,
		.rest		(rest)		,
		.adc_in		(adc_in)	,
		.adc_clk	(adc_clk)		
    	);

endmodule
