`timescale 1ns / 1ps
module SQR_top
	(
		input 	wire			clk			,
		input 	wire			rest_n			,
		input	wire	signed	[31:0]	s_axis_a_tdata		,
		
		output 	wire 	signed	[31:0]	fix_data			
    	);
    	/*
    	fix_float
    	*/
	
	wire			m_axis_result_tvalid_fix_float	;
	/*
	数据能否被接收
	*/
	wire	signed	[31:0]	float_data			;	
	/*
	float_data
	*/
	
	
	
	/*
	sqr
	*/
	wire			s_axis_a_tready_sqr		;
	/*
	可输入数据 sqr
	*/
	/*
	输出数据有效
	*/
	wire			m_axis_result_tvalid_sqr	;	
	
	wire	signed	[31:0]	sqr_out_data			;
	
  	/*
    	float_fix
    	*/
  	wire			s_axis_a_tready_float_fix	;
  	/*
  	是否可以输入数据
  	*/
  	wire			m_axis_result_tvalid_float_fix	;
  	/*
  	输出数据是否有效
  	*/
  	
    	fix_to_float	fix_to_float_top
	(
		.clk			(clk)			,
		.rest_n			(rest_n)		,
		.s_axis_a_tdata		(s_axis_a_tdata)	,
		/*
		fix_data
		*/
		.m_axis_result_tready	(s_axis_a_tready_sqr)	,
		/*
		后级能否接收
		*/
		.m_axis_result_tvalid	(m_axis_result_tvalid_fix_float),
		/*
		数据是否ok
		*/
		.float_data		(float_data)
		/*
		float_data
		*/
    	);
    	
    	
    	sqr	sqr_top
	(
		.clk			(clk)				,
		.rest_n			(rest_n)			,
		/*
		输入数据有效
		*/
		.s_axis_a_tvalid_sqr	(m_axis_result_tvalid_fix_float),
		/*
		可以输出数据
		*/
		.s_axis_a_tready_sqr	(s_axis_a_tready_sqr)		,
		
		.sqr_in_data		(float_data)			,
		
		/*
		输出数据有效
		*/
		.m_axis_result_tvalid_sqr(m_axis_result_tvalid_sqr)	,
		
		/*
		下一级可以接受数据
		*/
		.m_axis_result_tready_sqr(s_axis_a_tready_float_fix)	,
	
		.sqr_out_data		(sqr_out_data)		
		
    	);
    	
    	
    	float_to_fix	float_to_fix_top
	(
		.clk				(clk)				,
		.rest_n				(rest_n)			,
		/*
		数据是否有效
		*/
		.s_axis_a_tvalid_float_fix	(m_axis_result_tvalid_sqr)	,
		
		.float_data			(sqr_out_data)			,
		
		/*
		数据是否可以输入
		*/
		.s_axis_a_tready_float_fix	(s_axis_a_tready_float_fix)	,
		
		.m_axis_result_tvalid		(m_axis_result_tvalid_float_fix),
		.fix_data			(fix_data)
		
    	);
    	
endmodule
