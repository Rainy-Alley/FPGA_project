`timescale 1ns / 1ps
/*
本模块试用于AD9226
*/
module adc_float
	(
		input 	wire			clk				,
		input 	wire			rest_n				,
		input 	wire		[11:0]	adc_data			,
		
		output	wire		[31:0]	m_axis_result_tdata_multi_adc	,
		
		output 	wire			m_axis_result_tvalid_adc_float	,
		// output wire m_axis_result_tvalid
		input 	wire			m_axis_result_tready_adc_float
		// input wire m_axis_result_tready
		
		/*
		-5 - 5 
		0 - 4095
		*/

    	);
    	
    	wire	signed	[15:0]	s_axis_a_tdata			;
	wire	signed	[31:0]	m_axis_result_tdata		;
	
	
	wire			s_axis_a_tready_multi_adc	;
	wire			s_axis_a_tvalid_multi_adc	;
	
	assign s_axis_a_tdata = adc_data - 'd2047		;
	
	fix_point_ip fix_point_ip_adc 
	(
  		.aclk(clk),                                  // input wire aclk
  		.s_axis_a_tvalid(rest_n),            // input wire s_axis_a_tvalid
  		.s_axis_a_tready(s_axis_a_tready),            // output wire s_axis_a_tready
  		.s_axis_a_tdata(s_axis_a_tdata),              // input wire [15 : 0] s_axis_a_tdata
  		.m_axis_result_tvalid(s_axis_a_tvalid_multi_adc),  // output wire m_axis_result_tvalid
  		.m_axis_result_tready(s_axis_a_tready_multi_adc),  // input wire m_axis_result_tready
  		.m_axis_result_tdata(m_axis_result_tdata)    // output wire [31 : 0] m_axis_result_tdata
	);
    	
    	floating_multi floating_multi_adc_float
    	(
		.aclk(clk),                                  // input wire aclk
		.s_axis_a_tvalid(s_axis_a_tvalid_multi_adc),            // input wire s_axis_a_tvalid
		.s_axis_a_tready(s_axis_a_tready_multi_adc),            // output wire s_axis_a_tready
		.s_axis_a_tdata(m_axis_result_tdata),              // input wire [31 : 0] s_axis_a_tdata
		
		.s_axis_b_tvalid(1'b1),            // input wire s_axis_b_tvalid
		.s_axis_b_tready(s_axis_b_tready),            // output wire s_axis_b_tready
		.s_axis_b_tdata('h3B200A01),              // input wire [31 : 0] s_axis_b_tdata
		
		.m_axis_result_tvalid(m_axis_result_tvalid_adc_float),  // output wire m_axis_result_tvalid
		.m_axis_result_tready(m_axis_result_tready_adc_float),  // input wire m_axis_result_tready
		.m_axis_result_tdata(m_axis_result_tdata_multi_adc)    // output wire [31 : 0] m_axis_result_tdata
	);
    	
    	
endmodule
