`timescale 1ns / 1ps
module I_Q#
	(
		parameter     	F_WORD = 32'd429496729	//4294967296(2^32)*i(频率)/10000000
        	
	)
	(
		input 	wire		clk				,
		input 	wire		rest_n				,
		input	wire		s_axis_a_tvalid_I		,          
		// input wire s_axis_a_tvalid
	  	output 	wire		s_axis_a_tready_I		,            
	  	// output wire s_axis_a_tready
	        input 	wire	[31:0]	adc_I				,   
	  	// input wire [31 : 0] s_axis_a_tdata
	  	
		input	wire		s_axis_a_tvalid_Q		,          
		// input wire s_axis_a_tvalid
	  	output 	wire		s_axis_a_tready_Q		,            
	  	// output wire s_axis_a_tready
	       	input 	wire	[31:0]	adc_Q				,
	  	// input wire [31 : 0] s_axis_a_tdata
	  	
	  	/*
    		result_I
		*/
		output 	wire 		m_axis_result_tvalid_result_I	,  
		// output wire m_axis_result_tvalid
		input 	wire		m_axis_result_tready_result_I	,
		// input wire m_axis_result_tready
		output 	wire	[31:0]	m_axis_result_tdata_result_I	,    
		// output wire [31 : 0] m_axis_result_tdata
		/*
		result_I
		*/
		
		
		/*
		result_Q
		*/
		output	wire 		m_axis_result_tvalid_result_Q	,  
		// output wire m_axis_result_tvalid
		input	wire		m_axis_result_tready_result_Q	,
		// input wire m_axis_result_tready
		output	wire	[31:0]	m_axis_result_tdata_result_Q	    
		// output wire [31 : 0] m_axis_result_tdata
		/*
		result_Q
		*/
	  	
    	);
    	
    	
    	
    	
    	/*
    	cos I
    	*/
    	wire 		m_axis_result_tvalid_cos;
    	// output wire m_axis_result_tvalid
  	wire 		m_axis_result_tready_cos;
  	// input wire m_axis_result_tready
  	wire 	[31:0]	m_axis_result_tdata_cos	;
  	// output wire [31 : 0] m_axis_result_tdata	
    	/*
    	cos I
    	*/
    	
    	
    	/*
    	sin Q
    	*/
    	wire 		m_axis_result_tvalid_sin;
    	// output wire m_axis_result_tvalid
  	wire 		m_axis_result_tready_sin;
  	// input wire m_axis_result_tready
  	wire 	[31:0]	m_axis_result_tdata_sin	;
  	// output wire [31 : 0] m_axis_result_tdata	
    	/*
    	sin Q
    	*/
    	
    	
    	/*
    	I
    	*/
    	float_cos#
    	(
    		.F_WORD(F_WORD),
    		.P_WORD('d2048)
    	)
    	float_cos_inst0
	(
		.clk			(clk),
		.rest_n			(rest_n),
		.m_axis_result_tvalid	(m_axis_result_tvalid_cos),
    		// output wire m_axis_result_tvalid
  		.m_axis_result_tready	(m_axis_result_tready_cos),
  		// input wire m_axis_result_tready
  		.m_axis_result_tdata	(m_axis_result_tdata_cos)
  		// output wire [31 : 0] m_axis_result_tdata	
	
    	);
    	
    	floating_point_I_Q floating_point_I 
    	(
  		.aclk(clk),                                  // input wire aclk
	  	.s_axis_a_tvalid(s_axis_a_tvalid_I),            // input wire s_axis_a_tvalid
	  	.s_axis_a_tready(s_axis_a_tready_I),            // output wire s_axis_a_tready
	  	.s_axis_a_tdata(adc_I),              // input wire [31 : 0] s_axis_a_tdata
	  	
	  	.s_axis_b_tvalid(m_axis_result_tvalid_cos),            // input wire s_axis_b_tvalid
	  	.s_axis_b_tready(m_axis_result_tready_cos),            // output wire s_axis_b_tready
	  	.s_axis_b_tdata(m_axis_result_tdata_cos),              // input wire [31 : 0] s_axis_b_tdata
	  	
	  	.m_axis_result_tvalid(m_axis_result_tvalid_result_I),  // output wire m_axis_result_tvalid
	  	.m_axis_result_tready(m_axis_result_tready_result_I),  // input wire m_axis_result_tready
	  	.m_axis_result_tdata(m_axis_result_tdata_result_I)    // output wire [31 : 0] m_axis_result_tdata
	);
    	
    	/*
    	I
    	*/
    	
    	
    	/*
    	Q
    	*/
    	float_sin#
    	(
    		.F_WORD(F_WORD),
    		.P_WORD('d4096)
    	)
    	float_sin_inst0
	(
		.clk			(clk),
		.rest_n			(rest_n),
		.m_axis_result_tvalid	(m_axis_result_tvalid_sin),
    		// output wire m_axis_result_tvalid
  		.m_axis_result_tready	(m_axis_result_tready_sin),
  		// input wire m_axis_result_tready
  		.m_axis_result_tdata	(m_axis_result_tdata_sin)
  		// output wire [31 : 0] m_axis_result_tdata	
	
    	);
    	
    	floating_point_I_Q floating_point_Q 
    	(
  		.aclk(clk),                                  // input wire aclk
	  	.s_axis_a_tvalid(s_axis_a_tvalid_Q),            // input wire s_axis_a_tvalid
	  	.s_axis_a_tready(s_axis_a_tready_Q),            // output wire s_axis_a_tready
	  	.s_axis_a_tdata(adc_Q),              // input wire [31 : 0] s_axis_a_tdata
	  	
	  	.s_axis_b_tvalid(m_axis_result_tvalid_sin),            // input wire s_axis_b_tvalid
	  	.s_axis_b_tready(m_axis_result_tready_sin),            // output wire s_axis_b_tready
	  	.s_axis_b_tdata(m_axis_result_tdata_sin),              // input wire [31 : 0] s_axis_b_tdata
	  	
	  	.m_axis_result_tvalid(m_axis_result_tvalid_result_Q),  // output wire m_axis_result_tvalid
	  	.m_axis_result_tready(m_axis_result_tready_result_Q),  // input wire m_axis_result_tready
	  	.m_axis_result_tdata(m_axis_result_tdata_result_Q)    // output wire [31 : 0] m_axis_result_tdata
	);
    	/*
    	Q
    	*/
endmodule
