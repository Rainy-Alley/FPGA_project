`timescale 1ns / 1ps
module fft_top
	(
		/*****	clk rest_n *****/
		input	wire		clk_fft			,
		input	wire		rest_n			,
		
		
		
		/*****	config	*****/
		input	wire		s_axis_config_tvalid	,
		/*
		主机准备好信号
		通知IP核可从tdata读取配置数据
		*/
		output 	wire		s_axis_config_tready	,
		/*
		FFT_IP准备好信号
		已准备好接收配置数据，高有效
		*/
		
		
		
		
		/****** s_axis_data *****/
		input	wire	[31:0]	s_axis_data_tdata	,
		/*
		数据通道，并行输入
		[27:16][11:0]={IM,RE} 真实数据位
		[31:28][15:12] = 'd0  补0位
		*/
		input 	wire		s_axis_data_tvalid	,
		/*
		通知IP核此时所有输入数据有效，每个上升沿读一次
		由上游主服务器(其他模块给出 eg: adc)所发出的信号表明其能够提供数据
		必须拉高 点数个周期才能拉低 建议数据采集就一直拉高
		*/
		output 	wire		s_axis_data_tready	,
		/*
		由核心(FFT IP)使用以表示其已准备好接收数据
		IP核已准备好接收配置数据，高有效
		*/
		input	wire		s_axis_data_tlast	,
		/*
		最后一个输入数据时，手动拉高（该数据被读取后，数据将不被读取）
		*/
		
		
		
		/****** m_axis_data *****/
		output 	wire	[63:0]	m_axis_data_tdata	,
		/*
		[58:32][26:0] = {IM，RE}
		*/
		output 	wire	[15:0]	m_axis_data_tuser	,
		/*
		[13:0]有效
		*/
		output 	wire		m_axis_data_tvalid	,
		/*
		通知外部设备此时所有输出数据有效，每个上升沿出一个数据
		*/
		input 	wire		m_axis_data_tready	,
		/*
		外设已准备好接收配置数据，高有效
		*/
		output 	wire		m_axis_data_tlast	,
		/*
		最后一个输出数据时，自动拉高
		*/	
		
		
		/***** event_frame_started *****/
		output 	wire		event_frame_started
		/*
		转换开始信号
		*/	
			
   	);	
   	/***** event *****/
   	/*
	event_frame_started
	：每一新的次fft开始时上跳一次。
	event_tlast_unexpected：当s_axis_data_tlast上跳，
	但IP核认为这并不是最后一个数据时上跳一次。
	event_tlast_missing：当IP核认为这是最后一个数据，
	但s_axis_data_tlast还是低的时候，该信号上跳。
	event_fft_overflow：在从数据输出通道输出的数据样本中发现溢出时上跳。
	只有当overflow选项被选择有效时才出现。
	event_data_in_channel_halt：当IP核需要新的输入数据但输入口并没有提供足够的数据时拉高。
	event_data_out_channel_halt：当 IP核尝试输出数据但无法输出时
	（可能时输出对象没有给IP核输出接收使能信号）拉高。只在Non-Realtime 模式下有效。
	event_status_channel_halt：当 IP核尝试输出数据到状态通道但无法输出时拉高。
	只在Non-Realtime 模式下有效。
	*/
   	                 
	
	wire	event_tlast_unexpected		;            
	
	wire	event_tlast_missing		;                 
	
	wire	event_status_channel_halt	;      
	
	wire	event_data_in_channel_halt    	;
	
	wire	event_data_out_channel_halt	;  
	
   	
   	
   	
   	fft fft_inst0 
   	(
		.aclk(clk_fft),                                                // input wire aclk
		/*
		IN
		时钟 
		*/
		.aresetn(rest_n),                                          // input wire aresetn
		/*
		IN
		低电平复位 
		*/
		
		/******* config ********/
		.s_axis_config_tdata({7'b0,1'b1}),                  // input wire [7 : 0] s_axis_config_tdata
		/*
		IN
		{7'b0,1'b1} 该通道见IP核里面为 1位有效位 高位补0 由于进行FFT故给1
		*/
		/*
		TDATA 格式 配置字段按照以下顺序（从最低有效位开始）被封装到 s_axis_config_tdata 向量中： 
		1. （可选）NFFT 加填充 
		2. （可选）字符长度加上填充部分 
		3. FWD /INV 
		4. （可选）SCALE_SCH 
		eg：
		三通道FFT变化
		FWD /INV 为 100 则通道2 FFT(正变换) 通道1,0 IFFT(逆变换)
		见P18 
		*/
		.s_axis_config_tvalid(s_axis_config_tvalid),                // input wire s_axis_config_tvalid
		/*
		IN
		由外部主控器发出信号，表明其能够提供数据。
		*/
		.s_axis_config_tready(s_axis_config_tready),                // output wire s_axis_config_tready
		/*
		OUT
		由核心发出的信号，表明其能够接收数据。
		s_axis_config_tvalid 和 s_axis_config_tready同时为高之后
		的下一个周期开始有值输出
		*/
		
		/****** s_axis_data *****/
		.s_axis_data_tdata(s_axis_data_tdata),                      // input wire [31 : 0] s_axis_data_tdata
		/*
		IN
		XN RE 采用二进制补码或单精度浮点格式表示。
		11-0
		
		XN IM 采用二进制补码或单精度浮点格式表示。
		27-16
		*/
		.s_axis_data_tvalid(s_axis_data_tvalid),                    // input wire s_axis_data_tvalid
		/*
		IN
		由上游主服务器(其他模块给出 eg: adc)所发出的信号表明其能够提供数据
		*/
		.s_axis_data_tready(s_axis_data_tready),                    // output wire s_axis_data_tready
		/*
		OUT
		由核心(FFT IP)使用以表示其已准备好接收数据
		*/
		.s_axis_data_tlast(s_axis_data_tlast),                      // input wire s_axis_data_tlast
		/*
		IN
		输入时域数据结束信号
		在该帧的最后一个样本中由上游主控器所确认。
		此信息仅由核心用于生成事件:
		event_tlast_unexpected(意外的时钟信号)
		event tlast_missing_events(时钟信号缺失)
		*/
		
		
		/******* m_axis ********/
		.m_axis_data_tdata(m_axis_data_tdata),                      // output wire [63 : 0] m_axis_data_tdata
		/*
		OUT
		0-26 RE
		32-58 IM
		*/
		.m_axis_data_tuser(m_axis_data_tuser),                      // output wire [15 : 0] m_axis_data_tuser
		/*
		OUT
		包含以下每个样本的附加信息:
		XK_INDEX(输出数据索引)：数据类型无符号二进制补码
		BLK_EXP（块指数）(无符号2进制补码):所应用的缩放量
		(即，原本未缩放的输出值被向下移动的位数)。
		该核心所拥有的每个FFT通道都包含一个单独的 BLK EXP 字段。
		仅在使用块浮点运算时才可用。
		OVFLO（算数溢出指示器）
		*/
		.m_axis_data_tvalid(m_axis_data_tvalid),                    // output wire m_axis_data_tvalid
		/*
		OUT
		由核心部分声明，意在表明其能够提供样本数据
		*/
		.m_axis_data_tready(m_axis_data_tready),                    // input wire m_axis_data_tready
		/*
		IN
		由外部从属设备发出的信号，表示其已准备好接收数据，
		*/
		.m_axis_data_tlast(m_axis_data_tlast),                      // output wire m_axis_data_tlast
		/*
		OUT
		输出频域数据结束信号
		框架的最后一组样本中的核心部分所确定的
		*/
		
		
		/******* event ********/
		/*
		event_frame_started
		：每一新的次fft开始时上跳一次。
		event_tlast_unexpected：当s_axis_data_tlast上跳，
		但IP核认为这并不是最后一个数据时上跳一次。
		event_tlast_missing：当IP核认为这是最后一个数据，
		但s_axis_data_tlast还是低的时候，该信号上跳。
		event_fft_overflow：在从数据输出通道输出的数据样本中发现溢出时上跳。
		只有当overflow选项被选择有效时才出现。
		event_data_in_channel_halt：当IP核需要新的输入数据但输入口并没有提供足够的数据时拉高。
		event_data_out_channel_halt：当 IP核尝试输出数据但无法输出时
		（可能时输出对象没有给IP核输出接收使能信号）拉高。只在Non-Realtime 模式下有效。
		event_status_channel_halt：当 IP核尝试输出数据到状态通道但无法输出时拉高。
		只在Non-Realtime 模式下有效。
		*/
		.event_frame_started(event_frame_started),                  // output wire event_frame_started
		/*
		OUT
		*/
		.event_tlast_unexpected(event_tlast_unexpected),            // output wire event_tlast_unexpected
		/*
		OUT
		*/
		.event_tlast_missing(event_tlast_missing),                  // output wire event_tlast_missing
		/*
		OUT
		*/
		.event_status_channel_halt(event_status_channel_halt),      // output wire event_status_channel_halt
		/*
		OUT
		*/
		.event_data_in_channel_halt(event_data_in_channel_halt),    // output wire event_data_in_channel_halt
		/*
		OUT
		*/
		.event_data_out_channel_halt(event_data_out_channel_halt)  // output wire event_data_out_channel_halt
		/*
		OUT
		*/
	);
   	
endmodule
