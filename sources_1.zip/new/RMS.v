`timescale 1ns / 1ps
module RMS #
    (
        parameter point = 'd16    
    )
    (
        input  	wire        	clk    		,
        input  	wire        	reset_n    	, // 修正端口名
        input  	wire 	[13:0] 	ADC_in    	,
        
        output 	wire 	[31:0] 	MS    
    );
    
    wire  [31:0] 	squares_data                	;
    wire  [27:0] 	mult_sum_of_squares_data        ;
    reg   [63:0] 	sum_of_squares_data            	;
    reg   [15:0] 	sum_of_squares_data_cnt         ;
    reg   [15:0] 	cnt_state_one                	;
    reg   [0:0] 	state                    	; // 显式声明位宽
    
    reg   [31:0] data_sum_average            		;
    reg   [31:0] data_save        [point- 1:0]   	;
    
    assign squares_data ={4'b0,mult_sum_of_squares_data};
    
    assign MS = data_sum_average                ;
    
    mult_sum_of_squares mult_sum_of_squares_inst0 
    (
        .CLK(clk),  // input wire CLK
        .A(ADC_in),      // input wire [13 : 0] A
        .B(ADC_in),      // input wire [13 : 0] B
        .P(mult_sum_of_squares_data)      // output wire [27 : 0] P
    );
    
    integer i    ;
    
    always @(posedge clk or negedge reset_n)
    if(!reset_n)
    begin
        sum_of_squares_data <= 'd0    ;
        sum_of_squares_data_cnt <= 'd0    ;
        state <= 'd0            ;
        cnt_state_one <= 'd0        ;
        data_sum_average <= 'd0        ;
        for(i = 0;i < point; i = i + 1'b1)
        begin
            data_save[i] = 'd0    ;
        end    
    end
    else
    begin
        case (state)
        'b0:
        begin
            sum_of_squares_data <= sum_of_squares_data + squares_data    ;
            if(sum_of_squares_data_cnt < (point - 1'b1))
            begin    
                data_save[sum_of_squares_data_cnt] <= squares_data    ;
                sum_of_squares_data_cnt <= sum_of_squares_data_cnt + 'd1;
            end
            else if(sum_of_squares_data_cnt == (point - 1'b1))
            begin
                data_save[sum_of_squares_data_cnt] <= squares_data    ;
                state <= 'd1                        ;
            end
            else
            begin
                sum_of_squares_data_cnt <= sum_of_squares_data_cnt    ;
                state <= state                        ;
            end
        end
        'b1:
        begin    
            sum_of_squares_data <= sum_of_squares_data + squares_data - data_save[cnt_state_one];
            data_save[cnt_state_one] <= squares_data            ;
            if(cnt_state_one < (point - 1'b1))
                cnt_state_one <= cnt_state_one + 1'b1;
            else
                cnt_state_one <= 0; // 添加循环逻辑
            data_sum_average <= sum_of_squares_data / point; // 使用参数化除法
            /*
            除法改成移位
            */
        end
        endcase
    end
    
endmodule