set_property IOSTANDARD LVCMOS33 [get_ports {key_state[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {key_state[0]}]
set_property PACKAGE_PIN B21 [get_ports {key_state[0]}]
set_property PACKAGE_PIN C22 [get_ports {key_state[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports clk]
set_property IOSTANDARD LVCMOS33 [get_ports rstn]
set_property PACKAGE_PIN W19 [get_ports clk]
set_property PACKAGE_PIN D21 [get_ports rstn]

set_property IOSTANDARD LVCMOS33 [get_ports O_qspi_mosi]
set_property IOSTANDARD LVCMOS33 [get_ports O_qspi_cs]
set_property IOSTANDARD LVCMOS33 [get_ports I_qspi_miso]
set_property PACKAGE_PIN T19 [get_ports O_qspi_cs]
set_property PACKAGE_PIN P22 [get_ports O_qspi_mosi]
set_property PACKAGE_PIN R22 [get_ports I_qspi_miso]

set_property IOSTANDARD LVCMOS33 [get_ports {led[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {led[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {led[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {led[0]}]
set_property PACKAGE_PIN U22 [get_ports {led[0]}]
set_property PACKAGE_PIN V22 [get_ports {led[1]}]
set_property PACKAGE_PIN W21 [get_ports {led[2]}]
set_property PACKAGE_PIN W22 [get_ports {led[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports rxd1]
set_property IOSTANDARD LVCMOS33 [get_ports rxd2]

set_property IOSTANDARD LVCMOS33 [get_ports txd1]
set_property IOSTANDARD LVCMOS33 [get_ports txd2]


set_property PACKAGE_PIN D19 [get_ports txd1]
set_property PACKAGE_PIN E19 [get_ports rxd1]

set_property PACKAGE_PIN C19 [get_ports txd2]
set_property PACKAGE_PIN C18 [get_ports rxd2]


set_property IOSTANDARD LVCMOS33 [get_ports ds]
set_property PACKAGE_PIN U20 [get_ports ds]
set_property PACKAGE_PIN T21 [get_ports sh_cp]
set_property PACKAGE_PIN V20 [get_ports st_cp]
set_property IOSTANDARD LVCMOS33 [get_ports st_cp]
set_property IOSTANDARD LVCMOS33 [get_ports sh_cp]
set_property IOSTANDARD LVCMOS33 [get_ports flash_rxd]
set_property IOSTANDARD LVCMOS33 [get_ports icap_flag]
set_property PACKAGE_PIN B22 [get_ports icap_flag]
set_property PACKAGE_PIN L21 [get_ports flash_rxd]

set_property C_CLK_INPUT_FREQ_HZ 300000000 [get_debug_cores dbg_hub]
set_property C_ENABLE_CLK_DIVIDER false [get_debug_cores dbg_hub]
set_property C_USER_SCAN_CHAIN 1 [get_debug_cores dbg_hub]
connect_debug_port dbg_hub/clk [get_nets clk_IBUF_BUFG]



set_property CFGBVS VCCO [current_design]
set_property CONFIG_VOLTAGE 3.3 [current_design]
set_property BITSTREAM.GENERAL.COMPRESS true [current_design]
set_property BITSTREAM.CONFIG.CONFIGRATE 50 [current_design]
set_property BITSTREAM.CONFIG.SPI_BUSWIDTH 4 [current_design]
set_property BITSTREAM.CONFIG.SPI_FALL_EDGE Yes [current_design]