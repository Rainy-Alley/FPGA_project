`timescale 1ps / 1ps

module uart_rx#(
	parameter	SYSTEM_CLK = 'd50_000_000,
	parameter	BAND_RATE = 'd115200
)(
	input	wire	clk,
	input	wire	rstn,
	input	wire	rxd,
	output	reg	[7:0]	dat,
	output	reg	done
);

localparam	Band_Cnt = SYSTEM_CLK / BAND_RATE / 'd16 - 'd1;
localparam	State_Max = 'd159;

reg	[1:0]	state_rxd;
reg	en;
reg	[8:0]	cnt_scan;
reg	[7:0]	cnt_state;
reg	[2:0]	state_start;
reg	[2:0]	state_dat[7:0];
reg	[2:0]	state_stop;
reg	state_done;
wire	nege_rxd;

always @(posedge clk or negedge rstn)
	if (!rstn) state_rxd <=#1 'd0;
	else state_rxd <=#1 {state_rxd[0], rxd};

always @(posedge clk or negedge rstn)
	if (!rstn) en <=#1 'b0;
	else if (nege_rxd) en <=#1 'b1;
	else if (cnt_state == State_Max || state_start[2]) en <=#1 'd0;
assign nege_rxd = (state_rxd == 'b10);

always @(posedge clk or negedge rstn)
	if (!rstn) cnt_scan <=#1 'd0;
	else if (en)
		if (cnt_scan >= Band_Cnt) cnt_scan <=#1 'd0;
		else cnt_scan <=#1 cnt_scan + 'b1;
	else cnt_scan <=#1 'd0;

always @(posedge clk or negedge rstn)
	if (!rstn) cnt_state <=#1 'd0;
	else if (en) begin
		if (state_done) begin
			if (State_Max <= cnt_state) cnt_state <=#1 'd0;
			else cnt_state <=#1 cnt_state + 'b1;
		end
	end else cnt_state <=#1 'd0;

always @(posedge clk or negedge rstn)
	if (!rstn) begin
		state_start <=#1 'd0;
		state_dat[0] <=#1 'd0;
		state_dat[1] <=#1 'd0;
		state_dat[2] <=#1 'd0;
		state_dat[3] <=#1 'd0;
		state_dat[4] <=#1 'd0;
		state_dat[5] <=#1 'd0;
		state_dat[6] <=#1 'd0;
		state_dat[7] <=#1 'd0;
		state_stop <=#1 'd0;
	end else if (en) begin
		if (state_done) begin
			case (cnt_state)
				5,6,7,8,9,10,11:state_start <=#1 state_start + rxd;
				21,22,23,24,25,26,27:state_dat[0] <=#1 state_dat[0] + rxd;
				37,38,39,40,41,42,43:state_dat[1] <=#1 state_dat[1] + rxd;
				53,54,55,56,57,58,59:state_dat[2] <=#1 state_dat[2] + rxd;
				69,70,71,72,73,74,75:state_dat[3] <=#1 state_dat[3] + rxd;
				85,86,87,88,89,90,91:state_dat[4] <=#1 state_dat[4] + rxd;
				101,102,103,104,105,106,107:state_dat[5] <=#1 state_dat[5] + rxd;
				117,118,119,120,121,122,123:state_dat[6] <=#1 state_dat[6] + rxd;
				133,134,135,136,137,138,139:state_dat[7] <=#1 state_dat[7] + rxd;
				149,150,151,152,153,154,155:state_stop <=#1 state_stop + rxd;
			endcase
		end
	end else begin
		state_start <=#1 'd0;
		state_dat[0] <=#1 'd0;
		state_dat[1] <=#1 'd0;
		state_dat[2] <=#1 'd0;
		state_dat[3] <=#1 'd0;
		state_dat[4] <=#1 'd0;
		state_dat[5] <=#1 'd0;
		state_dat[6] <=#1 'd0;
		state_dat[7] <=#1 'd0;
		state_stop <=#1 'd0;
	end

always @(posedge clk or negedge rstn)
	if (!rstn) dat <=#1 'd0;
	else if (cnt_state == State_Max) begin
		dat[0] <=#1 state_dat[0][2];
		dat[1] <=#1 state_dat[1][2];
		dat[2] <=#1 state_dat[2][2];
		dat[3] <=#1 state_dat[3][2];
		dat[4] <=#1 state_dat[4][2];
		dat[5] <=#1 state_dat[5][2];
		dat[6] <=#1 state_dat[6][2];
		dat[7] <=#1 state_dat[7][2];
	end

always @(posedge clk or negedge rstn)
	if (!rstn) state_done <=#1 'b0;
	else if (cnt_scan == Band_Cnt) state_done <=#1 'b1;
	else state_done <=#1 'b0;

always @(posedge clk or negedge rstn)
	if (!rstn) done <=#1 'b0;
	else if (cnt_state == State_Max) done <=#1 'b1;
	else done <=#1 'b0;

endmodule
