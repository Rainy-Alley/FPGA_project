module puf(
        input   clk_50m,
        input   rstn,
        output  wire [127:0]out_puf
    );

    
reg  clk_25m;
wire shift_in;
wire shift_in_inv;
assign shift_in_inv = ~shift_in;
assign shift_in = rstn ? clk_25m : 1'b0;
assign clk_puf  = rstn ? clk_50m : 1'b0;
always @(posedge clk_50m or negedge rstn)
        if(!rstn)
                clk_25m<='d0;
        else
                clk_25m <= !clk_25m;
    //��Ҫ128��
wire [127:0] lut_out1;  //�Ĵ�������
wire [127:0] mux_out1;  //MUX���
wire [127:0] CARRY_OUT1 [2:0];   //��Ч����
wire [127:0] lut_out2;  //�Ĵ�������
wire [127:0] mux_out2;  //MUX���
wire [127:0] CARRY_OUT2 [2:0];   //��Ч����

genvar i;

generate                
        for (i = 0; i < 128; i = i + 1)begin
                SRL16E #(
			.INIT(16'h0000)	// Initial Value of Shift Register
		) SRL16E_instA (
			.Q(lut_out1[i]),	// SRL data output
			.A0(1'b1),	// Select[0] input
			.A1(1'b1),	// Select[1] input
			.A2(1'b1),	// Select[2] input
			.A3(1'b1),	// Select[3] input
			.CE(1'b1),	// Clock enable input
			.CLK(clk_puf),	// Clock input
			.D(shift_in)	// SRL data input
		);
		SRL16E #(
			.INIT(16'hFFFF)	// Initial Value of Shift Register
		) SRL16E_instB (
			.Q(lut_out2[i]),	// SRL data output
			.A0(1'b1),	// Select[0] input
			.A1(1'b1),	// Select[1] input
			.A2(1'b1),	// Select[2] input
			.A3(1'b1),	// Select[3] input
			.CE(1'b1),	// Clock enable input
			.CLK(clk_puf),	// Clock input
			.D(shift_in_inv)	// SRL data input
		);
		CARRY4 CARRY4_inst1 (
                        .CO({mux_out1[i],CARRY_OUT1[i][2:0]}),	// 4-bit carry out
                        .O(),		// 4-bit carry chain XOR data out
                        .CI(mux_out2[i]),		// 1-bit carry cascade input
                        .CYINIT(1'b0),	// 1-bit carry initialization
                        .DI(4'b0000),	// 4-bit carry-MUX data in
                        .S({lut_out1[i],3'b111})	// 4-bit carry-MUX select input
                );
                CARRY4 CARRY4_inst2 (
                        .CO({mux_out2[i],CARRY_OUT2[i][2:0]}),	// 4-bit carry out
                        .O(),		// 4-bit carry chain XOR data out
                        .CI(1'b1),		// 1-bit carry cascade input
                        .CYINIT(1'b1),	// 1-bit carry initialization
                        .DI(4'b0000),	// 4-bit carry-MUX data in
                        .S({2'b11,lut_out2[i],1'b1})	// 4-bit carry-MUX select input
                );
                FDPE #(
                        .INIT(1'b0)		// Initial value of register (1'b0 or 1'b1)
                ) FDPE_inst (
                        .Q(out_puf[i]),			// 1-bit Data output
                        .C(clk_puf),		// 1-bit Clock input
                        .CE(1'b1),		// 1-bit Clock enable input
                        .PRE(mux_out1[i]),	// 1-bit Asynchronous preset input
                        .D(out_puf[i])		// 1-bit Data input
                );
        end
endgenerate

endmodule
