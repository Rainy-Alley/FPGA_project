//����rxd���ۼƷ��͵�128λ֮������ɣ�
//DATA_WIDTHΪָ�����ܳ���
//rx_data_done������һ�����壨����Ϊ�������ڣ�
//ͬʱ���res_dat_buff
module uart_data_rx#(	 parameter DATA_WIDTH = 'd128)
(
        input   clk_50m,
        input   rstn,
        input   rxd,
        output  reg [DATA_WIDTH-1:0] res_dat_buff,//����128λAES�������
        output  reg rx_data_done
);
localparam rx_done_cnt_max=DATA_WIDTH/8;
reg [7:0]rx_done_cnt=0;

reg [DATA_WIDTH-1:0]res_dat;
/* uartrx */    
wire    rx_done;
reg     rx_done_1;
reg     rx_done_2;
wire    rx_done_posedge_pluse;
wire    [7:0] rx_dat;
assign  rx_done_posedge_pluse = ({rx_done_1,rx_done_2}=='b10)?'d1:'d0;

always @(posedge clk_50m)
begin
    rx_done_1<=rx_done; 
    rx_done_2<=rx_done_1;
end

always @(posedge clk_50m or negedge rstn)
begin
    if(!rstn)
    begin
        rx_done_cnt<='d0;
        res_dat<='d0;
        rx_data_done<='d0;
        res_dat_buff<='d0;
    end
    else
    begin
        if(rx_done_posedge_pluse)
        begin                            
                rx_done_cnt <=rx_done_cnt+'d1;
                res_dat<={res_dat[DATA_WIDTH-9:0],rx_dat};       
         end
        else if(rx_done_cnt >= rx_done_cnt_max)
        begin
            rx_done_cnt<='d0;
            res_dat_buff<=res_dat;
            res_dat<='d0;
            rx_data_done<='d1;
        end
        if((rx_done_cnt<rx_done_cnt_max)||rx_data_done)
         begin
            res_dat_buff<=res_dat_buff;
            rx_data_done<='d0;
         end
    end
end


uart_rx#(
	.SYSTEM_CLK('d50_000_000),
	.BAND_RATE ('d115200)
)uart_rx_u1(
	.clk(clk_50m),
	.rstn(rstn),
	.rxd(rxd),
	.dat(rx_dat),
	.done(rx_done)
);


endmodule
