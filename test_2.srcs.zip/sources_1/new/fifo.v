`timescale 1ps / 1ps

module fifo(
        input   clk,
        input   rstn,
        
        input   [7:0]   dat,
        input   wr_clk,
        input   rd_clk,
        
        output  read_able, 
        output  [7:0]   o_rx_dat
    );

wire    [7:0]   a_dat;
wire    [7:0]   b_dat;
assign o_rx_dat = rd_en_a ? a_dat : rd_en_b ? b_dat : 'hff;
reg     [12:0]  wr_cnt;
reg     [12:0]  rd_cnt;

always @(posedge wr_clk or negedge rstn)//д����
        if(!rstn)wr_cnt<='d0;
        else if(wr_cnt=='d4096) wr_cnt<='d0;
        else wr_cnt<=wr_cnt+1'b1;
        
always @(posedge rd_clk or negedge rstn)//������
        if(!rstn)rd_cnt<='d0;
        else if(rd_cnt=='d4096) rd_cnt<='d0;
        else    rd_cnt<=rd_cnt+1'b1;

//��д�߼�����
reg     wr_en_a, wr_en_b;
reg     rd_en_a, rd_en_b;
wire    wr_full_a,wr_full_b;
wire    rd_empty_a,rd_empty_b;
reg     delay_flag;
//д������Ӻ�20��ʱ��
reg     [7:0]   delay_cnt;
always @(posedge clk or negedge rstn)begin
        if(!rstn)begin
                wr_en_a<='d1;rd_en_a<='d0;delay_cnt<='d0;
                wr_en_b<='d0;rd_en_b<='d0;delay_flag<='d0;
        end else begin
                if(wr_full_a)begin
                        wr_en_a<='d0;
                        wr_en_b<='d1;
                        rd_en_a<='d1;
                        rd_en_b<='d0;
                end else if(wr_full_b)begin
                        wr_en_a<='d1;
                        wr_en_b<='d0;
                        rd_en_a<='d0;
                        rd_en_b<='d1;
                end else if((!rd_empty_a&&rd_cnt=='d4095) || (!rd_empty_b&&rd_cnt=='d4095))begin 
//                        rd_en_a<='d0;
                        delay_flag<='d1;
//                end else if(rd_empty_b&&rd_cnt=='d4096)begin 
//                        rd_en_b<='d0;
//                        delay_flag<='d1;
                end
                if(delay_flag)begin
                        if(delay_cnt=='d100)begin
                                delay_cnt<='d0;
                                delay_flag<='d0;
                                if(rd_en_a)rd_en_a<='d0;
                                else if(rd_en_b)rd_en_b<='d0;
                        end else delay_cnt<=delay_cnt+1'b1;
                end
        end
end

reg     [1:0]   cnt;
reg     cnt_set;
wire    rd_clk_in;
assign rd_clk_in = cnt_set?rd_clk:clk;
assign read_able = cnt_set?(rd_en_a | rd_en_b):0;
always @(posedge clk or negedge rstn)begin
        if(!rstn)begin
                cnt <= 'd0;
                cnt_set<='d0;
        end else begin
                if(wr_full_a||wr_full_b||(delay_flag&&delay_cnt<='d100))begin
                        if(cnt=='d0)cnt_set<='d1;
                        else cnt <= cnt + 1'b1;
                end else if((rd_empty_a && rd_en_a) || (rd_empty_b && rd_en_b))
                        cnt_set<='d0;
                else if(rd_empty_a || rd_empty_b)begin
                        if(cnt=='d0)
                                cnt<='d0;
                end
        end
end


             
ASFIFO # ( 
       .WIDTH(8), 
       .PTR(12) 
)ASFIFO_A(
        .wrclk	 	(wr_clk),
        .wr_rst_n	(rstn),
        .wr_data	(dat),
        .wr_en		(wr_en_a),
        .wr_full	(wr_full_a),

        .rdclk		(rd_clk_in),
        .rd_rst_n	(rstn),
        .rd_data	(a_dat),
        .rd_en		(rd_en_a),
        .rd_empty	(rd_empty_a)
);

ASFIFO # ( 
       .WIDTH(8), 
       .PTR(12) 
)ASFIFO_B(
        .wrclk	 	(wr_clk ),
        .wr_rst_n	(rstn),
        .wr_data	(dat),
        .wr_en		(wr_en_b),
        .wr_full	(wr_full_b),

        .rdclk		(rd_clk_in),
        .rd_rst_n	(rstn),
        .rd_data	(b_dat),
        .rd_en		(rd_en_b),
        .rd_empty	(rd_empty_b)
);
  
endmodule
