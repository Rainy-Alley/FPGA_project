module flash_control #(
        parameter       END_ADDR = 24'h000000
)(
    /*****system*****/
    input         I_clk         ,
    input         I_rst_n       ,
    /*****user*****/
    input       [23:0]  R_flash_addr,//�����ַ0x001000 -> 0xfff000
    input       [7:0]   i_dat,//��������
    output      reg finish_sector,//����д����ɱ�־ 1:��� 0:��д��     
    output      O_byte_flag,//һ�ֽ���ɱ�־λ
//    output      reg     [11:0] addr_byte,//4096����ַ  
    /*****SPI*****/
//    output        O_qspi_clk    , // SPI���ߴ���ʱ����
    output        clk_25M    ,
    output        O_qspi_cs     , // SPI����Ƭѡ�ź�
    output        O_qspi_mosi   , // SPI��������ź��ߣ�Ҳ��QSPI Flash�������ź���
    input         I_qspi_miso     // SPI���������ź��ߣ�Ҳ��QSPI Flash������ź���
);
//reg finish_sector;
reg [6:0]   R_state             ;
reg [7:0]   R_flash_cmd         ;
reg [23:0]  I_R_flash_addr      ;
reg         R_clk_25M           ;
reg [4:0]   R_cmd_type          ;
                           
wire        W_done_sig          ;
wire [7:0]  W_read_data         ;
wire        W_read_byte_valid   ;
wire [2:0]  R_qspi_state        ;

assign clk_25M = R_clk_25M; 
////////////////////////////////////////////////////////////////////          
//���ܣ�����Ƶ�߼�          
////////////////////////////////////////////////////////////////////          
always @(posedge I_clk or negedge I_rst_n)begin
    if(!I_rst_n) 
        R_clk_25M   <=  1'b0        ;
    else 
        R_clk_25M   <=  ~R_clk_25M  ;
end
////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////
//���ܣ�����״̬��
////////////////////////////////////////////////////////////////////
always @(posedge R_clk_25M or negedge I_rst_n)begin
    if(!I_rst_n) begin
            R_state         <=  4'd0        ;
            R_flash_cmd     <=  8'h00       ;
            R_cmd_type      <=  5'b0_0000   ;
            finish_sector   <=  0;
     end else begin
            case(R_state)           
                7'd0:begin//��Device IDָ��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin 
                                R_flash_cmd  <= 8'h9f           ; 
                                I_R_flash_addr <= R_flash_addr           ; 
                                R_cmd_type   <= 5'b1_0000       ; 
                        end     
                    end 
                7'd1:begin//дWrite disable instruction
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ;
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin 
                                R_flash_cmd <= 8'h04            ; 
                                R_cmd_type  <= 5'b1_0100        ; 
                        end     
                    end                
                7'd2:begin//дʹ��(Write Enable)ָ��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin
                                R_flash_cmd <= 8'h06            ; 
                                R_cmd_type  <= 5'b1_0001        ; 
                        end
                    end         
                7'd3:begin// ��������(Sector Erase)ָ��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin 
                                R_flash_cmd <= 8'h20            ; 
                                I_R_flash_addr<= R_flash_addr            ; 
                                R_cmd_type  <= 5'b1_0010        ; 
                         end
                    end
            
                7'd4:begin//��״̬�Ĵ���1, ��Busyλ(״̬�Ĵ���1�����λ)Ϊ0ʱ��ʾ�����������
                        if(W_done_sig) begin 
                                if(W_read_data[0]==1'b0)begin 
                                        R_flash_cmd <= 8'h00            ; 
                                        R_state     <= R_state + 1'b1   ;
                                        R_cmd_type  <= 5'b0_0000        ; 
                                end else begin 
                                        R_flash_cmd <= 8'h05        ; 
                                        R_cmd_type  <= 5'b1_0011    ; 
                                end
                        end else begin 
                                R_flash_cmd <= 8'h05        ; 
                                R_cmd_type  <= 5'b1_0011    ; 
                       end
                    end
                /*дʹ��->ҳд��->���Ĵ���������ѭ��16��д��һ������*///0
                //*****************0*******************//
                7'd5:begin//дʹ��(Write Enable)ָ��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin
                                R_flash_cmd <= 8'h06            ; 
                                R_cmd_type  <= 5'b1_0001        ; 
                        end
                    end             
                7'd6:begin//ҳ��̲���(Page Program): �Ѵ����ROM�е�����д��QSPI Flash��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin 
                                R_flash_cmd <= 8'h02            ; 
                                I_R_flash_addr<= R_flash_addr            ; 
                                R_cmd_type  <= 5'b1_0101        ; 
                        end
                    end
                7'd7:begin//��״̬�Ĵ���1, ��Busyλ(״̬�Ĵ���1�����λ)Ϊ0ʱ��ʾд�������
                        if(W_done_sig) begin 
                                if(W_read_data[0]==1'b0) begin 
                                        R_flash_cmd <= 8'h00            ; 
                                        R_state     <= R_state + 1'b1   ;
                                        R_cmd_type  <= 5'b0_0000        ; 
                                end else begin 
                                        R_flash_cmd <= 8'h05        ; 
                                        R_cmd_type  <= 5'b1_0011    ; 
                                end
                        end else begin 
                                R_flash_cmd <= 8'h05        ; 
                                R_cmd_type  <= 5'b1_0011    ; 
                        end
                    end 
                //*****************1*******************//
                7'd8:begin//дʹ��(Write Enable)ָ�� 
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin
                                R_flash_cmd <= 8'h06            ; 
                                R_cmd_type  <= 5'b1_0001        ; 
                        end
                    end   
                7'd9:begin//ҳ��̲���(Page Program): �Ѵ����ROM�е�����д��QSPI Flash��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin 
                                R_flash_cmd <= 8'h02            ; 
                                I_R_flash_addr<= R_flash_addr+24'h0000100; 
                                R_cmd_type  <= 5'b1_0101        ; 
                        end
                    end
                7'd10:begin//��״̬�Ĵ���1, ��Busyλ(״̬�Ĵ���1�����λ)Ϊ0ʱ��ʾд�������
                        if(W_done_sig) begin 
                                if(W_read_data[0]==1'b0) begin 
                                        R_flash_cmd <= 8'h00            ; 
                                        R_state     <= R_state + 1'b1   ;
                                        R_cmd_type  <= 5'b0_0000        ; 
                                end else begin 
                                        R_flash_cmd <= 8'h05        ; 
                                        R_cmd_type  <= 5'b1_0011    ; 
                                end
                        end else begin 
                                R_flash_cmd <= 8'h05        ; 
                                R_cmd_type  <= 5'b1_0011    ; 
                        end
                    end          
                //*****************2*******************//
                7'd11:begin//дʹ��(Write Enable)ָ�� 
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin
                                R_flash_cmd <= 8'h06            ; 
                                R_cmd_type  <= 5'b1_0001        ; 
                        end
                    end   
                7'd12:begin//ҳ��̲���(Page Program): �Ѵ����ROM�е�����д��QSPI Flash��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin 
                                R_flash_cmd <= 8'h02            ; 
                                I_R_flash_addr<= R_flash_addr+24'h0000200; 
                                R_cmd_type  <= 5'b1_0101        ; 
                        end
                    end
                7'd13:begin//��״̬�Ĵ���1, ��Busyλ(״̬�Ĵ���1�����λ)Ϊ0ʱ��ʾд�������
                        if(W_done_sig) begin 
                                if(W_read_data[0]==1'b0) begin 
                                        R_flash_cmd <= 8'h00            ; 
                                        R_state     <= R_state + 1'b1   ;
                                        R_cmd_type  <= 5'b0_0000        ; 
                                end else begin 
                                        R_flash_cmd <= 8'h05        ; 
                                        R_cmd_type  <= 5'b1_0011    ; 
                                end
                        end else begin 
                                R_flash_cmd <= 8'h05        ; 
                                R_cmd_type  <= 5'b1_0011    ; 
                        end
                    end
                //*****************3*******************//
                7'd14:begin//дʹ��(Write Enable)ָ�� 
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin
                                R_flash_cmd <= 8'h06            ; 
                                R_cmd_type  <= 5'b1_0001        ; 
                        end
                    end   
                7'd15:begin//ҳ��̲���(Page Program): �Ѵ����ROM�е�����д��QSPI Flash��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin 
                                R_flash_cmd <= 8'h02            ; 
                                I_R_flash_addr<= R_flash_addr+24'h0000300; 
                                R_cmd_type  <= 5'b1_0101        ; 
                        end
                    end
                7'd16:begin//��״̬�Ĵ���1, ��Busyλ(״̬�Ĵ���1�����λ)Ϊ0ʱ��ʾд�������
                        if(W_done_sig) begin 
                                if(W_read_data[0]==1'b0) begin 
                                        R_flash_cmd <= 8'h00            ; 
                                        R_state     <= R_state + 1'b1   ;
                                        R_cmd_type  <= 5'b0_0000        ; 
                                end else begin 
                                        R_flash_cmd <= 8'h05        ; 
                                        R_cmd_type  <= 5'b1_0011    ; 
                                end
                        end else begin 
                                R_flash_cmd <= 8'h05        ; 
                                R_cmd_type  <= 5'b1_0011    ; 
                        end
                    end
                //*****************4*******************//
                7'd17:begin//дʹ��(Write Enable)ָ�� 
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin
                                R_flash_cmd <= 8'h06            ; 
                                R_cmd_type  <= 5'b1_0001        ; 
                        end
                    end   
                7'd18:begin//ҳ��̲���(Page Program): �Ѵ����ROM�е�����д��QSPI Flash��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin 
                                R_flash_cmd <= 8'h02            ; 
                                I_R_flash_addr<= R_flash_addr+24'h0000400; 
                                R_cmd_type  <= 5'b1_0101        ; 
                        end
                    end
                7'd19:begin//��״̬�Ĵ���1, ��Busyλ(״̬�Ĵ���1�����λ)Ϊ0ʱ��ʾд�������
                        if(W_done_sig) begin 
                                if(W_read_data[0]==1'b0) begin 
                                        R_flash_cmd <= 8'h00            ; 
                                        R_state     <= R_state + 1'b1   ;
                                        R_cmd_type  <= 5'b0_0000        ; 
                                end else begin 
                                        R_flash_cmd <= 8'h05        ; 
                                        R_cmd_type  <= 5'b1_0011    ; 
                                end
                        end else begin 
                                R_flash_cmd <= 8'h05        ; 
                                R_cmd_type  <= 5'b1_0011    ; 
                        end
                    end
                //*****************5*******************//
                7'd20:begin//дʹ��(Write Enable)ָ�� 
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin
                                R_flash_cmd <= 8'h06            ; 
                                R_cmd_type  <= 5'b1_0001        ; 
                        end
                    end   
                7'd21:begin//ҳ��̲���(Page Program): �Ѵ����ROM�е�����д��QSPI Flash��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin 
                                R_flash_cmd <= 8'h02            ; 
                                I_R_flash_addr<= R_flash_addr+24'h0000500; 
                                R_cmd_type  <= 5'b1_0101        ; 
                        end
                    end
                7'd22:begin//��״̬�Ĵ���1, ��Busyλ(״̬�Ĵ���1�����λ)Ϊ0ʱ��ʾд�������
                        if(W_done_sig) begin 
                                if(W_read_data[0]==1'b0) begin 
                                        R_flash_cmd <= 8'h00            ; 
                                        R_state     <= R_state + 1'b1   ;
                                        R_cmd_type  <= 5'b0_0000        ; 
                                end else begin 
                                        R_flash_cmd <= 8'h05        ; 
                                        R_cmd_type  <= 5'b1_0011    ; 
                                end
                        end else begin 
                                R_flash_cmd <= 8'h05        ; 
                                R_cmd_type  <= 5'b1_0011    ; 
                        end
                    end
                //*****************6*******************//
                7'd23:begin//дʹ��(Write Enable)ָ�� 
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin
                                R_flash_cmd <= 8'h06            ; 
                                R_cmd_type  <= 5'b1_0001        ; 
                        end
                    end   
                7'd24:begin//ҳ��̲���(Page Program): �Ѵ����ROM�е�����д��QSPI Flash��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin 
                                R_flash_cmd <= 8'h02            ; 
                                I_R_flash_addr<= R_flash_addr+24'h0000600; 
                                R_cmd_type  <= 5'b1_0101        ; 
                        end
                    end
                7'd25:begin//��״̬�Ĵ���1, ��Busyλ(״̬�Ĵ���1�����λ)Ϊ0ʱ��ʾд�������
                        if(W_done_sig) begin 
                                if(W_read_data[0]==1'b0) begin 
                                        R_flash_cmd <= 8'h00            ; 
                                        R_state     <= R_state + 1'b1   ;
                                        R_cmd_type  <= 5'b0_0000        ; 
                                end else begin 
                                        R_flash_cmd <= 8'h05        ; 
                                        R_cmd_type  <= 5'b1_0011    ; 
                                end
                        end else begin 
                                R_flash_cmd <= 8'h05        ; 
                                R_cmd_type  <= 5'b1_0011    ; 
                        end
                    end    
                //*****************7*******************//
                7'd26:begin//дʹ��(Write Enable)ָ�� 
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin
                                R_flash_cmd <= 8'h06            ; 
                                R_cmd_type  <= 5'b1_0001        ; 
                        end
                    end   
                7'd27:begin//ҳ��̲���(Page Program): �Ѵ����ROM�е�����д��QSPI Flash��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin 
                                R_flash_cmd <= 8'h02            ; 
                                I_R_flash_addr<= R_flash_addr+24'h0000700; 
                                R_cmd_type  <= 5'b1_0101        ; 
                        end
                    end
                7'd28:begin//��״̬�Ĵ���1, ��Busyλ(״̬�Ĵ���1�����λ)Ϊ0ʱ��ʾд�������
                        if(W_done_sig) begin 
                                if(W_read_data[0]==1'b0) begin 
                                        R_flash_cmd <= 8'h00            ; 
                                        R_state     <= R_state + 1'b1   ;
                                        R_cmd_type  <= 5'b0_0000        ; 
                                end else begin 
                                        R_flash_cmd <= 8'h05        ; 
                                        R_cmd_type  <= 5'b1_0011    ; 
                                end
                        end else begin 
                                R_flash_cmd <= 8'h05        ; 
                                R_cmd_type  <= 5'b1_0011    ; 
                        end
                    end
                //*****************8*******************//
                7'd29:begin//дʹ��(Write Enable)ָ�� 
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin
                                R_flash_cmd <= 8'h06            ; 
                                R_cmd_type  <= 5'b1_0001        ; 
                        end
                    end   
                7'd30:begin//ҳ��̲���(Page Program): �Ѵ����ROM�е�����д��QSPI Flash��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin 
                                R_flash_cmd <= 8'h02            ; 
                                I_R_flash_addr<= R_flash_addr+24'h0000800; 
                                R_cmd_type  <= 5'b1_0101        ; 
                        end
                    end
                7'd31:begin//��״̬�Ĵ���1, ��Busyλ(״̬�Ĵ���1�����λ)Ϊ0ʱ��ʾд�������
                        if(W_done_sig) begin 
                                if(W_read_data[0]==1'b0) begin 
                                        R_flash_cmd <= 8'h00            ; 
                                        R_state     <= R_state + 1'b1   ;
                                        R_cmd_type  <= 5'b0_0000        ; 
                                end else begin 
                                        R_flash_cmd <= 8'h05        ; 
                                        R_cmd_type  <= 5'b1_0011    ; 
                                end
                        end else begin 
                                R_flash_cmd <= 8'h05        ; 
                                R_cmd_type  <= 5'b1_0011    ; 
                        end
                    end
                //*****************9*******************//
                7'd32:begin//дʹ��(Write Enable)ָ�� 
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin
                                R_flash_cmd <= 8'h06            ; 
                                R_cmd_type  <= 5'b1_0001        ; 
                        end
                    end   
                7'd33:begin//ҳ��̲���(Page Program): �Ѵ����ROM�е�����д��QSPI Flash��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin 
                                R_flash_cmd <= 8'h02            ; 
                                I_R_flash_addr<= R_flash_addr+24'h0000900; 
                                R_cmd_type  <= 5'b1_0101        ; 
                        end
                    end
                7'd34:begin//��״̬�Ĵ���1, ��Busyλ(״̬�Ĵ���1�����λ)Ϊ0ʱ��ʾд�������
                        if(W_done_sig) begin 
                                if(W_read_data[0]==1'b0) begin 
                                        R_flash_cmd <= 8'h00            ; 
                                        R_state     <= R_state + 1'b1   ;
                                        R_cmd_type  <= 5'b0_0000        ; 
                                end else begin 
                                        R_flash_cmd <= 8'h05        ; 
                                        R_cmd_type  <= 5'b1_0011    ; 
                                end
                        end else begin 
                                R_flash_cmd <= 8'h05        ; 
                                R_cmd_type  <= 5'b1_0011    ; 
                        end
                    end
                //*****************a*******************//
                7'd35:begin//дʹ��(Write Enable)ָ�� 
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin
                                R_flash_cmd <= 8'h06            ; 
                                R_cmd_type  <= 5'b1_0001        ; 
                        end
                    end   
                7'd36:begin//ҳ��̲���(Page Program): �Ѵ����ROM�е�����д��QSPI Flash��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin 
                                R_flash_cmd <= 8'h02            ; 
                                I_R_flash_addr<= R_flash_addr+24'h0000a00; 
                                R_cmd_type  <= 5'b1_0101        ; 
                        end
                    end
                7'd37:begin//��״̬�Ĵ���1, ��Busyλ(״̬�Ĵ���1�����λ)Ϊ0ʱ��ʾд�������
                        if(W_done_sig) begin 
                                if(W_read_data[0]==1'b0) begin 
                                        R_flash_cmd <= 8'h00            ; 
                                        R_state     <= R_state + 1'b1   ;
                                        R_cmd_type  <= 5'b0_0000        ; 
                                end else begin 
                                        R_flash_cmd <= 8'h05        ; 
                                        R_cmd_type  <= 5'b1_0011    ; 
                                end
                        end else begin 
                                R_flash_cmd <= 8'h05        ; 
                                R_cmd_type  <= 5'b1_0011    ; 
                        end
                    end
                //*****************b*******************//
                7'd38:begin//дʹ��(Write Enable)ָ�� 
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin
                                R_flash_cmd <= 8'h06            ; 
                                R_cmd_type  <= 5'b1_0001        ; 
                        end
                    end   
                7'd39:begin//ҳ��̲���(Page Program): �Ѵ����ROM�е�����д��QSPI Flash��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin 
                                R_flash_cmd <= 8'h02            ; 
                                I_R_flash_addr<= R_flash_addr+24'h0000b00; 
                                R_cmd_type  <= 5'b1_0101        ; 
                        end
                    end
                7'd40:begin//��״̬�Ĵ���1, ��Busyλ(״̬�Ĵ���1�����λ)Ϊ0ʱ��ʾд�������
                        if(W_done_sig) begin 
                                if(W_read_data[0]==1'b0) begin 
                                        R_flash_cmd <= 8'h00            ; 
                                        R_state     <= R_state + 1'b1   ;
                                        R_cmd_type  <= 5'b0_0000        ; 
                                end else begin 
                                        R_flash_cmd <= 8'h05        ; 
                                        R_cmd_type  <= 5'b1_0011    ; 
                                end
                        end else begin 
                                R_flash_cmd <= 8'h05        ; 
                                R_cmd_type  <= 5'b1_0011    ; 
                        end
                    end
                //*****************c*******************//
                7'd41:begin//дʹ��(Write Enable)ָ�� 
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin
                                R_flash_cmd <= 8'h06            ; 
                                R_cmd_type  <= 5'b1_0001        ; 
                        end
                    end   
                7'd42:begin//ҳ��̲���(Page Program): �Ѵ����ROM�е�����д��QSPI Flash��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin 
                                R_flash_cmd <= 8'h02            ; 
                                I_R_flash_addr<= R_flash_addr+24'h0000c00; 
                                R_cmd_type  <= 5'b1_0101        ; 
                        end
                    end
                7'd43:begin//��״̬�Ĵ���1, ��Busyλ(״̬�Ĵ���1�����λ)Ϊ0ʱ��ʾд�������
                        if(W_done_sig) begin 
                                if(W_read_data[0]==1'b0) begin 
                                        R_flash_cmd <= 8'h00            ; 
                                        R_state     <= R_state + 1'b1   ;
                                        R_cmd_type  <= 5'b0_0000        ; 
                                end else begin 
                                        R_flash_cmd <= 8'h05        ; 
                                        R_cmd_type  <= 5'b1_0011    ; 
                                end
                        end else begin 
                                R_flash_cmd <= 8'h05        ; 
                                R_cmd_type  <= 5'b1_0011    ; 
                        end
                    end
                //*****************d*******************//
                7'd44:begin//дʹ��(Write Enable)ָ�� 
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin
                                R_flash_cmd <= 8'h06            ; 
                                R_cmd_type  <= 5'b1_0001        ; 
                        end
                    end   
                7'd45:begin//ҳ��̲���(Page Program): �Ѵ����ROM�е�����д��QSPI Flash��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin 
                                R_flash_cmd <= 8'h02            ; 
                                I_R_flash_addr<= R_flash_addr+24'h0000d00; 
                                R_cmd_type  <= 5'b1_0101        ; 
                        end
                    end
                7'd46:begin//��״̬�Ĵ���1, ��Busyλ(״̬�Ĵ���1�����λ)Ϊ0ʱ��ʾд�������
                        if(W_done_sig) begin 
                                if(W_read_data[0]==1'b0) begin 
                                        R_flash_cmd <= 8'h00            ; 
                                        R_state     <= R_state + 1'b1   ;
                                        R_cmd_type  <= 5'b0_0000        ; 
                                end else begin 
                                        R_flash_cmd <= 8'h05        ; 
                                        R_cmd_type  <= 5'b1_0011    ; 
                                end
                        end else begin 
                                R_flash_cmd <= 8'h05        ; 
                                R_cmd_type  <= 5'b1_0011    ; 
                        end
                    end
                //*****************e*******************//
                7'd47:begin//дʹ��(Write Enable)ָ�� 
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin
                                R_flash_cmd <= 8'h06            ; 
                                R_cmd_type  <= 5'b1_0001        ; 
                        end
                    end   
                7'd48:begin//ҳ��̲���(Page Program): �Ѵ����ROM�е�����д��QSPI Flash��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin 
                                R_flash_cmd <= 8'h02            ; 
                                I_R_flash_addr<= R_flash_addr+24'h0000e00; 
                                R_cmd_type  <= 5'b1_0101        ; 
                        end
                    end
                7'd49:begin//��״̬�Ĵ���1, ��Busyλ(״̬�Ĵ���1�����λ)Ϊ0ʱ��ʾд�������
                        if(W_done_sig) begin 
                                if(W_read_data[0]==1'b0) begin 
                                        R_flash_cmd <= 8'h00            ; 
                                        R_state     <= R_state + 1'b1   ;
                                        R_cmd_type  <= 5'b0_0000        ; 
                                end else begin 
                                        R_flash_cmd <= 8'h05        ; 
                                        R_cmd_type  <= 5'b1_0011    ; 
                                end
                        end else begin 
                                R_flash_cmd <= 8'h05        ; 
                                R_cmd_type  <= 5'b1_0011    ; 
                        end
                    end
                //*****************f*******************//
                7'd50:begin//дʹ��(Write Enable)ָ�� 
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin
                                R_flash_cmd <= 8'h06            ; 
                                R_cmd_type  <= 5'b1_0001        ; 
                        end
                    end   
                7'd51:begin//ҳ��̲���(Page Program): �Ѵ����ROM�е�����д��QSPI Flash��
                        if(W_done_sig) begin 
                                R_flash_cmd <= 8'h00            ; 
                                R_state     <= R_state + 1'b1   ; 
                                R_cmd_type  <= 5'b0_0000        ; 
                        end else begin 
                                R_flash_cmd <= 8'h02            ; 
                                I_R_flash_addr<= R_flash_addr+24'h0000f00; 
                                R_cmd_type  <= 5'b1_0101        ; 
                        end
                    end
                7'd52:begin//��״̬�Ĵ���1, ��Busyλ(״̬�Ĵ���1�����λ)Ϊ0ʱ��ʾд�������
                        if(W_done_sig) begin 
                                if(W_read_data[0]==1'b0) begin 
                                        R_flash_cmd <= 8'h00            ; 
                                        R_state     <= R_state + 1'b1   ;
                                        R_cmd_type  <= 5'b0_0000        ; 
                                end else begin 
                                        R_flash_cmd <= 8'h05        ; 
                                        R_cmd_type  <= 5'b1_0011    ; 
                                end
                        end else begin 
                                R_flash_cmd <= 8'h05        ; 
                                R_cmd_type  <= 5'b1_0011    ; 
                        end
                    end        
                7'd53:begin// ���һ������д��4096������
                        R_flash_cmd <= 8'h00            ; 
                        R_state     <= 7'd54             ;
                        R_cmd_type  <= 5'b0_0000        ; 
                        finish_sector <= 1'b1;//���д������
                    end
                7'd54:begin
                        R_state     <= 7'd54             ;
//                        if(I_R_flash_addr >= END_ADDR-24'h000f00)begin
//                                R_flash_cmd <= 8'h00            ; 
//                                R_state     <= 7'd54             ;
//                                R_cmd_type  <= 5'b0_0000        ;
//                                finish_sector <= 1'b0;//�����´�д������
//                                led <= 1; 
//                        end else begin
//                                R_state     <= 7'd0         ;
//                                finish_sector <= 1'b1;//�����´�д������
//                        end
                    end
//                default :   R_state     <= 7'd0         ;
            endcase
        end           
end 
qspi_driver U_qspi_driver(
        .O_qspi_clk          (O_qspi_clk        ), // SPI���ߴ���ʱ����
        .O_qspi_cs           (O_qspi_cs         ), // SPI����Ƭѡ�ź�
        .O_qspi_mosi         (O_qspi_mosi       ), // SPI��������ź��ߣ�Ҳ��QSPI Flash�������ź���
        .I_qspi_miso         (I_qspi_miso       ), // SPI���������ź��ߣ�Ҳ��QSPI Flash������ź���

        .I_rst_n             (I_rst_n           ), // ��λ�ź�

        .I_clk_25M           (R_clk_25M         ), // 25MHzʱ���ź�
        .I_cmd_type          (R_cmd_type        ), // ��������
        .I_cmd_code          (R_flash_cmd       ), // ������
        .I_qspi_addr         (I_R_flash_addr    ), // QSPI Flash��ַ
        .I_dat               (i_dat             ),
        
        .O_byte_flag         (O_byte_flag       ),
        .O_done_sig          (W_done_sig        ), // ָ��ִ�н�����־
        .O_read_data         (W_read_data       ), // ��QSPI Flash����������
        .O_read_byte_valid   (W_read_byte_valid ), // ��һ���ֽ���ɵı�־
        .O_qspi_state        (R_qspi_state      )  // ״̬���������ڶ��������
);
     
endmodule
