`timescale 1ns / 1ps

module tb_icap();

reg	sclk;
reg	rstn;
reg	icap_flag;

icap_start icap_start(
	.sclk(sclk),
	.rst_n(!rstn),
	.icap_flag(icap_flag)
);

initial sclk = 1;
always#10 sclk = ~sclk;
initial begin
	rstn = 0;
	icap_flag = 'b0;
	#201
	rstn = 1;
	icap_flag = 'b1;
	#20
	icap_flag = 'b0;
	#20000
	icap_flag = 'b1;
	#20
	icap_flag = 'b0;
	#20000
	$stop;
end
endmodule
