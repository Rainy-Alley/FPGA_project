`timescale 1ns / 1ps
`include "./sm3_cfg.v"
//`include "D:\0_project\241031\SM3_test_1031\SM3_test_1031.srcs\sources_1\new\sm3_cfg.v"
//////////////////////////////////////////////////////////////////////////////////
// Author:        ljgibbs / lf_gibbs@163.com
// Create Date: 2020/07/29 
// Design Name: sm3
// Module Name: sm3_core_top
// Description:
//      SM3 顶层模块，例化下层的 SM3 填充、扩展以及迭代压缩三个模�?
//      输入位宽：INPT_DW1 定义，支�?32/64
//      输出位宽：与输入位宽�?�?
// Dependencies: 
//      inc/sm3_cfg.v
// Revision:
// Revision 0.01 - File Created
//////////////////////////////////////////////////////////////////////////////////

module entrypt_top(
    input                       clk,//top.clk
    input                       rst_n,//top.rst_n
    input                       en,//
    input                       [255:0] data,//top.msg_inpt_d
    output       reg              [255:0]out_data,//top.cmprss_otpt_res
    output                     entrypt_down//top.msg_inpt_rdy
    );

    //sm3_core_top���ź�������
 sm3_if int_if();
reg [255:0]data_buff;
reg [63:0]msg_inpt_d;
reg [7:0]msg_inpt_vld_byte;
reg msg_inpt_vld;
reg msg_inpt_lst;
wire msg_inpt_rdy;
wire [255:0]data_out_buff;
wire done_pluse;
reg done_pluse_1;
reg cnt2 ;
assign entrypt_down= ({cnt2 ,done_pluse_1}=='b01)? 'b1 : 'b0 ;
always@(posedge done_pluse_1 or negedge rst_n)
begin
        if(!rst_n) cnt2<='d0;
        else        cnt2<= 'd1+cnt2;
end
 always@(posedge clk or negedge rst_n)
begin
        if(!rst_n)
        begin
                data_buff<='d0;
        end
        else
        begin
                if(en)
                begin
                        data_buff<=data;
                end
        end
end
 always @(posedge clk ) done_pluse_1<=done_pluse;
reg state=0;
localparam S1='d0;//����ʱ��
localparam S2='d1;//��ʼ����

//����sm3
sm3_core_top U_sm3_core_top (
//`ifdef EPICSIM
//    input                       clk,
//    input                       rst_n,
//    input [`INPT_DW1:0]         msg_inpt_d,
//    input [`INPT_BYTE_DW1:0]    msg_inpt_vld_byte,
//    input                       msg_inpt_vld,
//    input                       msg_inpt_lst,
    
//    output                      msg_inpt_rdy,

//    output[255:0]               cmprss_otpt_res,
//    output                      cmprss_otpt_vld
//`else

//----------------------------------------

    //shixu logic
    //int_if,
    .clk                    (clk                  ),
    .rst_n                  (rst_n                 ),
    //in
    .msg_inpt_d           (msg_inpt_d             ),
    .msg_inpt_vld_byte    (msg_inpt_vld_byte      ),
    .msg_inpt_vld         (msg_inpt_vld           ),
    .msg_inpt_lst         (msg_inpt_lst           ),
    //out
    .msg_inpt_rdy         (msg_inpt_rdy           ),
    .cmprss_otpt_res      (data_out_buff              ),
    .cmprss_otpt_vld      (   done_pluse        )
    
//----------------------------------------
    
//`endif
);

always@(posedge clk or negedge rst_n)
begin
        if(!rst_n)
        begin
                state<='d0;
        end
        else
        begin
                 case (state)
                 0:begin
                            if(en)
                            begin
                                    state<='d1;
                            end
                    end               
                 1:begin
                        if(done_pluse_1)
                       begin
                                     state<='d0;
                       end
                 end
                  endcase
        end
end
always@(posedge clk or negedge rst_n)
begin
        if(!rst_n)
        begin
                out_data<='d0;
        end
        else
        begin
                if(done_pluse)
                begin
                    out_data<=data_out_buff;
                end
                else
                begin
                         out_data<=out_data;
                end
        end
end

reg [3:0]cnt;
always@(posedge clk or negedge rst_n)
begin
        if(!rst_n)
        begin
            cnt<='d0;
        end
        else 
        begin
                if(state=='d1)
                begin
                            if(msg_inpt_rdy)
                            begin
                                    cnt<=cnt+'d1;
                                    if(cnt>=5)
                                    begin
                                        cnt<='d0;
                                    end
                                    case(cnt)
                                    0:begin
                                        msg_inpt_lst <= 0;
                                        msg_inpt_vld <= 0;   
                                    end
                                    1:begin
                                         msg_inpt_vld <= 1;   
                                         end
                                    2:begin
                                         msg_inpt_d <= data_buff[63:0];
                                         msg_inpt_vld_byte <= 8'b1111_1111;
                                    end
                                    3:begin
                                         msg_inpt_d <= data_buff[127:64];
                                         msg_inpt_vld_byte <= 8'b1111_1111;
                                    end
                                    4:begin
                                         msg_inpt_d <= data_buff[191:128];
                                         msg_inpt_vld_byte <= 8'b1111_1111;
                                    end
                                    5:begin
                                         msg_inpt_d <= data_buff[255:192];
                                         msg_inpt_vld_byte <= 8'b1111_1111;
                                         msg_inpt_lst <= 1;
                                    end
                                    endcase
                           end
                end
                else
                begin
                        msg_inpt_vld<='d0;
                        msg_inpt_lst<='d0;
                end
        end
end


    
//    `ifdef SM3_INPT_DW_32
//    assign      int_if.msg_inpt_d        =   data[31:0];
//    //assign      int_if.msg_inpt_vld_byte =   sm3_data_vld_byte[3:0];
//    `elsif SM3_INPT_DW_64
//    assign      int_if.msg_inpt_d        =   data;
//    //assign      int_if.msg_inpt_vld_byte =   sm3_data_vld_byte;
//    `endif
    
    
endmodule

