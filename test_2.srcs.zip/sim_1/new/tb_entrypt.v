`timescale 1ns / 1ps

module tb_entrypt();
wire [255:0]out_data;
wire entrypt_down;
reg  en;
reg clk;
reg rst_n;
reg [255:0]data;
always #10 clk<=~clk;
initial begin
clk<='d0; rst_n<='d1; #200 rst_n<='d0; #20 rst_n<='d1;data<='d123454;
            end
            
always begin #2000000 en<=1;data<=data+'d500;#20en<=0;end

entrypt_top entrypt_top(
.clk(clk),//top.clk
.rst_n(rst_n),//top.rst_n
.en(en),//
.data(data),//top.msg_inpt_d
.out_data(out_data),//top.cmprss_otpt_res
.entrypt_down(entrypt_down)//top.msg_inpt_rdy
    );


endmodule
